-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-02-2025 a las 12:21:24
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `viviendas_tuteladas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `director`
--

CREATE TABLE `director` (
  `id_director` int(11) NOT NULL,
  `nombre_director` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `clave` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `director`
--

INSERT INTO `director` (`id_director`, `nombre_director`, `fecha_nacimiento`, `telefono`, `email`, `clave`) VALUES
(2, 'Director', '1975-02-16', '632547910', 'director@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informe_usuario`
--

CREATE TABLE `informe_usuario` (
  `id_informe_usuario` int(11) NOT NULL,
  `id_vivienda` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_informe` date NOT NULL,
  `estado` enum('pendiente','resuelto') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `informe_usuario`
--

INSERT INTO `informe_usuario` (`id_informe_usuario`, `id_vivienda`, `id_usuario`, `id_responsable`, `titulo`, `descripcion`, `fecha_informe`, `estado`) VALUES
(50, 62, 57, 36, 'Informe Diario', 'Juan ha pasado un día tranquilo y ha seguido toda su rutina sin problemas. Ha hecho todo lo que tenía planeado.', '2025-02-15', 'resuelto'),
(51, 62, 58, 36, 'Cita medica', 'Julia tiene una cita médica programada para el jueves, por lo que deberá solicitar el día libre en su trabajo. Preguntar si ya ha pedido el día.', '2025-02-15', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `informe_vivienda`
--

CREATE TABLE `informe_vivienda` (
  `id_informe_vivienda` int(11) NOT NULL,
  `id_vivienda` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` text NOT NULL,
  `fecha_informe` date NOT NULL,
  `estado` enum('pendiente','resuelto') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `informe_vivienda`
--

INSERT INTO `informe_vivienda` (`id_informe_vivienda`, `id_vivienda`, `id_responsable`, `titulo`, `descripcion`, `fecha_informe`, `estado`) VALUES
(40, 62, 36, 'Goteras en el baño', 'Hay goteras en el baño y está filtrando agua. Necesita que lo revisen y lo arreglen cuanto antes.', '2025-02-15', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensajes`
--

CREATE TABLE `mensajes` (
  `id_mensaje` int(11) NOT NULL,
  `id_remitente_responsable` int(11) DEFAULT NULL,
  `id_remitente_director` int(11) DEFAULT NULL,
  `id_destinatario_responsable` int(11) DEFAULT NULL,
  `id_destinatario_director` int(11) DEFAULT NULL,
  `mensaje` text NOT NULL,
  `fecha_envio` timestamp NOT NULL DEFAULT current_timestamp(),
  `leido` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mensajes`
--

INSERT INTO `mensajes` (`id_mensaje`, `id_remitente_responsable`, `id_remitente_director`, `id_destinatario_responsable`, `id_destinatario_director`, `mensaje`, `fecha_envio`, `leido`) VALUES
(24, NULL, 2, 36, NULL, 'Hola .Espero que te encuentres bien. Solo quería recordarte que mañana tendrás que hacer el turno de tu compañero. Asegúrate de estar preparado y de llegar a tiempo.\r\nCualquier duda o inconveniente, no dudes en avisarme.\r\nSaludos,\r\nDirector', '2025-02-15 09:36:31', 0),
(25, 36, NULL, NULL, 2, 'Estimado Director\r\nEspero que se encuentre bien. Me gustaría solicitar el día 30 de junio de 2025 libre debido a rezones personales. ¿Sería posible concederme ese día?\r\nQuedo a la espera de su respuesta.\r\nAtentamente,\r\nResponsable 01', '2025-02-15 10:02:30', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable`
--

CREATE TABLE `responsable` (
  `id_responsable` int(11) NOT NULL,
  `id_vivienda` int(11) NOT NULL,
  `nombre_responsable` varchar(50) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `titulo_academico` varchar(50) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `clave` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `responsable`
--

INSERT INTO `responsable` (`id_responsable`, `id_vivienda`, `nombre_responsable`, `fecha_nacimiento`, `titulo_academico`, `telefono`, `email`, `clave`) VALUES
(36, 62, 'Responsable 010', '1987-12-26', 'Tabajador social', '666333000', 'responsable01@gmail.com', '123456'),
(37, 62, 'Responsable 02', '1997-05-14', 'Integrador social', '632014750', 'responsable02@gmail.com', '123456'),
(38, 63, 'Responsable 03', '1975-09-10', 'Tabajadora social', '654001478', 'responsable03@gmail.com', '123456'),
(41, 63, 'Responsable 04', '2000-07-07', 'Tabajadora social', '632001447', 'responsable04@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `responsable_usuario`
--

CREATE TABLE `responsable_usuario` (
  `id_resp_usu` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `id_vivienda` int(11) NOT NULL,
  `nombre_usuario` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `situacion_personal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `id_vivienda`, `nombre_usuario`, `fecha_nacimiento`, `telefono`, `email`, `situacion_personal`) VALUES
(57, 62, 'Juan Prado Gálvez', '2001-12-23', '674102571', 'juan@gmail.com', 'Juan Prado Gálvez, de 24 años, tiene una discapacidad visual del 70% y trabaja en un kiosco de la ONCE, donde atiende a los clientes con profesionalidad y dedicación. Aunque es bastante autónomo, decidió trasladarse a una vivienda tutelada porque vivir solo le resultaba complicado, especialmente en tareas como cocinar o desplazarse por espacios no adaptados. Al principio le costó el cambio, pero pronto encontró en la vivienda un ambiente acogedor, donde ha hecho amigos con quienes comparte charlas y ratitos de juegos . Su rutina es estable: trabaja por las mañanas y, por las tardes, participa en actividades organizadas en la vivienda o sale a caminar con otros residentes. Ahora se siente más seguro y acompañado sin perder su independencia.'),
(58, 62, 'Julia López Dorado', '1989-07-15', '698442330', 'julia@gmail.com', 'Julia López Dorado, de 36 años, tiene una discapacidad intelectual moderada que afecta su autonomía. Trabaja en una organización de voluntariado, colaborando con dedicación. Se mudó a una vivienda tutelada para recibir apoyo en su día a día, ya que vivir sola le resultaba difícil. Al principio le costó adaptarse, pero pronto encontró un ambiente acogedor y amistoso. Su rutina incluye trabajar por las mañanas y participar en actividades en la vivienda por las tardes. Ahora se siente más segura y apoyada, avanzando hacia una mayor independencia.'),
(59, 63, 'Sara Francés Rubio', '1888-11-29', '654117445', 'sara@gmail.com', 'Sara, de 37 años, ha enfrentado problemas de drogodependencia en el pasado, lo que le dificultaba mantener una vida estable. Tras un proceso de rehabilitación, decidió mudarse a una vivienda tutelada para continuar su recuperación en un entorno controlado. Actualmente trabaja en una tienda, lo que le ha dado un sentido de propósito y estabilidad. Aunque al principio fue difícil, pronto encontró apoyo en los profesionales y otros residentes. Ahora sigue un plan de tratamiento, participa en actividades grupales y se siente más motivada para mantener su independencia y bienestar.'),
(60, 63, 'Samuel Comino Casas', '1985-06-10', '633202147', 'samuel@gmail.com', 'Samuel, de 40 años, tiene síndrome de Down, lo que le presenta algunas dificultades en su autonomía. Se mudó a una vivienda tutelada para recibir el apoyo necesario en su día a día. Actualmente trabaja como jardinero, realizando tareas con mucha dedicación y responsabilidad. Aunque al principio el cambio fue complicado, pronto encontró un entorno acogedor que le permitió hacer nuevos amigos y sentirse más seguro. Participa en actividades sociales y sigue una rutina estable que le ha dado mayor confianza e independencia.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vivienda`
--

CREATE TABLE `vivienda` (
  `id_vivienda` int(11) NOT NULL,
  `nombre_vivienda` varchar(50) NOT NULL,
  `calle` varchar(300) NOT NULL,
  `numero` int(3) NOT NULL,
  `piso` varchar(10) DEFAULT NULL,
  `ciudad` varchar(50) NOT NULL,
  `provincia` varchar(50) NOT NULL,
  `codigo_postal` int(5) NOT NULL,
  `num_usuarios` int(11) NOT NULL,
  `informacion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vivienda`
--

INSERT INTO `vivienda` (`id_vivienda`, `nombre_vivienda`, `calle`, `numero`, `piso`, `ciudad`, `provincia`, `codigo_postal`, `num_usuarios`, `informacion`) VALUES
(62, 'TOLEDO 001', 'Reconquista', 18, '2ªA', 'Toledo', 'Toledo', 40001, 2, 'La vivienda tutelada TOLEDO 001 está adaptada y diseñada para ofrecer autonomía y bienestar a sus residentes. Cuenta con dos habitaciones, un baño adaptado para personas con movilidad reducida, y una sala común acogedora para la convivencia. Además, dispone de una cocina equipada y mobiliario funcional que garantiza comodidad y accesibilidad. Su ubicación permite un entorno seguro y adaptado a las necesidades de sus ocupantes, proporcionando un ambiente de apoyo y supervisión cuando es necesario.'),
(63, 'TOLEDO 002', 'Comercio', 12, '1ºB', 'Toledo', 'Toledo', 40005, 3, 'La vivienda tutelada TOLEDO 002 está adaptada para ofrecer confort y autonomía a sus residentes. Dispone de tres habitaciones, dos baños adaptados para mayor comodidad, y una sala de estar amplia y luminosa que fomenta la convivencia. La cocina está totalmente equipada, permitiendo a los residentes desenvolverse con facilidad en su día a día. Además, cuenta con zonas comunes adaptadas para el ocio y el descanso, creando un ambiente seguro y acogedor. Su distribución y equipamiento están pensados para garantizar bienestar y accesibilidad a todos sus ocupantes.');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `director`
--
ALTER TABLE `director`
  ADD PRIMARY KEY (`id_director`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `informe_usuario`
--
ALTER TABLE `informe_usuario`
  ADD PRIMARY KEY (`id_informe_usuario`),
  ADD KEY `id_vivienda` (`id_vivienda`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_responsable` (`id_responsable`);

--
-- Indices de la tabla `informe_vivienda`
--
ALTER TABLE `informe_vivienda`
  ADD PRIMARY KEY (`id_informe_vivienda`),
  ADD KEY `id_vivienda` (`id_vivienda`),
  ADD KEY `id_responsable` (`id_responsable`);

--
-- Indices de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD PRIMARY KEY (`id_mensaje`),
  ADD KEY `fk_remitente_responsable` (`id_remitente_responsable`),
  ADD KEY `fk_remitente_director` (`id_remitente_director`),
  ADD KEY `fk_destinatario_responsable` (`id_destinatario_responsable`),
  ADD KEY `fk_destinatario_director` (`id_destinatario_director`);

--
-- Indices de la tabla `responsable`
--
ALTER TABLE `responsable`
  ADD PRIMARY KEY (`id_responsable`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `id_vivienda` (`id_vivienda`);

--
-- Indices de la tabla `responsable_usuario`
--
ALTER TABLE `responsable_usuario`
  ADD PRIMARY KEY (`id_resp_usu`),
  ADD KEY `id_responsable` (`id_responsable`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `id_vivienda` (`id_vivienda`);

--
-- Indices de la tabla `vivienda`
--
ALTER TABLE `vivienda`
  ADD PRIMARY KEY (`id_vivienda`),
  ADD UNIQUE KEY `nombre_vivienda` (`nombre_vivienda`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `director`
--
ALTER TABLE `director`
  MODIFY `id_director` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `informe_usuario`
--
ALTER TABLE `informe_usuario`
  MODIFY `id_informe_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `informe_vivienda`
--
ALTER TABLE `informe_vivienda`
  MODIFY `id_informe_vivienda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT de la tabla `mensajes`
--
ALTER TABLE `mensajes`
  MODIFY `id_mensaje` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `responsable`
--
ALTER TABLE `responsable`
  MODIFY `id_responsable` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT de la tabla `responsable_usuario`
--
ALTER TABLE `responsable_usuario`
  MODIFY `id_resp_usu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT de la tabla `vivienda`
--
ALTER TABLE `vivienda`
  MODIFY `id_vivienda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `informe_usuario`
--
ALTER TABLE `informe_usuario`
  ADD CONSTRAINT `informe_usuario_ibfk_1` FOREIGN KEY (`id_vivienda`) REFERENCES `vivienda` (`id_vivienda`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `informe_usuario_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `informe_usuario_ibfk_3` FOREIGN KEY (`id_responsable`) REFERENCES `responsable` (`id_responsable`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `informe_vivienda`
--
ALTER TABLE `informe_vivienda`
  ADD CONSTRAINT `informe_vivienda_ibfk_1` FOREIGN KEY (`id_vivienda`) REFERENCES `vivienda` (`id_vivienda`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `informe_vivienda_ibfk_2` FOREIGN KEY (`id_responsable`) REFERENCES `responsable` (`id_responsable`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `mensajes`
--
ALTER TABLE `mensajes`
  ADD CONSTRAINT `fk_destinatario_director` FOREIGN KEY (`id_destinatario_director`) REFERENCES `director` (`id_director`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_destinatario_responsable` FOREIGN KEY (`id_destinatario_responsable`) REFERENCES `responsable` (`id_responsable`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_remitente_director` FOREIGN KEY (`id_remitente_director`) REFERENCES `director` (`id_director`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_remitente_responsable` FOREIGN KEY (`id_remitente_responsable`) REFERENCES `responsable` (`id_responsable`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `responsable`
--
ALTER TABLE `responsable`
  ADD CONSTRAINT `responsable_ibfk_1` FOREIGN KEY (`id_vivienda`) REFERENCES `vivienda` (`id_vivienda`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `responsable_usuario`
--
ALTER TABLE `responsable_usuario`
  ADD CONSTRAINT `responsable_usuario_ibfk_1` FOREIGN KEY (`id_responsable`) REFERENCES `responsable` (`id_responsable`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `responsable_usuario_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_vivienda`) REFERENCES `vivienda` (`id_vivienda`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
