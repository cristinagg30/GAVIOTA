<?php
/* Este script gestiona los informes relacionados con usuarios asociados al responsable logueado.
Permite al responsable visualizar los informes, eliminarlos y actualizar el estado de ellos.
También permite buscar incidencias por fechas y filtrar por su estado */

session_start();

require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php');
    exit;
}

$conexion = conectar_bd();

$mensaje = "";
$alertEliminar = "";
$alertActualizado = "";

function eliminar_informe($conn, $id_informe) {
    try {
        $sql = "DELETE FROM informe_usuario WHERE id_informe_usuario = :id_informe";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_informe', $id_informe, PDO::PARAM_INT);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error al eliminar el informe: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['eliminar_informe'])) {
    $id_informe = $_POST['eliminar_informe'];

    if (eliminar_informe($conexion, $id_informe)) {
        $alertEliminar = "Informe eliminada correctamente.";
    } else {
        $mensaje = "Error al eliminar el informe.";
    }
}

function obtener_informes_usuarios_asociados($conn, $id_responsable) {
    try {
        $sql = "SELECT iu.*, u.nombre_usuario AS nombre_usuario, r.nombre_responsable 
                FROM informe_usuario iu
                JOIN usuario u ON iu.id_usuario = u.id_usuario
                JOIN vivienda v ON u.id_vivienda = v.id_vivienda
                JOIN responsable r ON v.id_vivienda = r.id_vivienda
                WHERE r.id_responsable = :id_responsable
                ORDER BY iu.fecha_informe DESC"; 

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_responsable', $id_responsable, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Error al obtener los informes de los usuarios asociados: " . $e->getMessage());
        return [];
    }
}

$informes = [];
if (!empty($_SESSION['user_id']) && $_SERVER["REQUEST_METHOD"] === "GET") {
    $idResponsable = $_SESSION['user_id'];
    $informes = obtener_informes_usuarios_asociados($conexion, $idResponsable);
}

$soloPendientes = isset($_GET['mostrar_pendientes']) ? true : false; 
$soloResueltos = isset($_GET['mostrar_resueltos']) ? true : false;
$mostrarTodas = isset($_GET['mostrar_informes']) ? true : false;

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : null; 

    $sql = "SELECT iu.*, u.nombre_usuario, r.nombre_responsable FROM informe_usuario iu
            JOIN usuario u ON iu.id_usuario = u.id_usuario
            JOIN responsable r ON r.id_responsable = iu.id_responsable
            WHERE iu.id_responsable = :id_responsable";

    if ($fechaSeleccionada) {
        $sql .= " AND iu.fecha_informe = :fecha_informe";
    }

    if ($soloPendientes) {
        $sql .= " AND iu.estado = 'pendiente'";
    }

    if ($soloResueltos) {
        $sql .= " AND iu.estado = 'resuelto'";
    }

    $stmt = $conexion->prepare($sql);
    $stmt->bindParam(':id_responsable', $idResponsable);

    if ($fechaSeleccionada) {
        $stmt->bindParam(':fecha_informe', $fechaSeleccionada);
    }

    $stmt->execute();
    $informes = $stmt->fetchAll();
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id_informe']) && isset($_POST['estado'])) {
    $conexion = conectar_bd();

    $id_informe = $_POST['id_informe'];
    $estado = $_POST['estado'];

    if ($estado !== 'pendiente' && $estado !== 'resuelto') {
        echo "Error: El estado debe ser 'pendiente' o 'resuelto'.";
        exit;
    }

    try {
        $sql = "UPDATE informe_usuario SET estado = :estado WHERE id_informe_usuario = :id_informe";
        $stmt = $conexion->prepare($sql);
        $stmt->bindParam(':estado', $estado);
        $stmt->bindParam(':id_informe', $id_informe);
        $stmt->execute();

        header("Location: update_informe_usuario.php");
        exit; 
    } catch (PDOException $e) {
        echo "Error al actualizar el estado: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de informes de los Usuarios</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/update_responsable.css">
</head>
<script>

function cambiarEstado(event, form) {
    event.preventDefault(); 

    var estadoActual = form.estado.value;
    var idinforme = form.id_informe.value;
    var boton = document.getElementById('btn-' + idinforme);
    var estadoField = document.getElementById('estado-' + idinforme);

    if (estadoActual === 'pendiente') {
        boton.textContent = 'Informe Resuelto';
        boton.classList.remove('btn-danger');
        boton.classList.add('btn-success');
        estadoField.value = 'resuelto';
    } else if (estadoActual === 'resuelto') {
        boton.textContent = 'Informe Pendiente';
        boton.classList.remove('btn-success');
        boton.classList.add('btn-danger');
        estadoField.value = 'pendiente';
    }

    form.submit();
}

function mostrarModal(idinforme) {
    document.getElementById('idinforme').value = idinforme; 
    document.getElementById('confirmModal').style.display = 'flex';
    document.getElementById('overlay').style.display = 'block';
}

function cerrarModal() {
    document.getElementById('confirmModal').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

function confirmarEliminacion() {
    document.getElementById('eliminarForm').submit();
}
</script>
<body>

<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Gestión de usuarios<p class="nom-vivienda"><?php echo htmlspecialchars($_SESSION['nombre_vivienda']); ?></p></h3>
            <?php if (!empty($alertEliminar) || !empty($alertActualizado)): ?>
                <div class="alert">
                    <h4>
                        <?php if (!empty($alertEliminar)): ?>
                            <i class="bi bi-check2-circle"></i> <?php echo $alertEliminar; ?>
                        <?php endif; ?>
                        <?php if (!empty($alertActualizado)): ?>
                            <i class="bi bi-check2-circle"></i> <?php echo $alertActualizado; ?>
                        <?php endif; ?>
                    </h4>
                </div>
            <?php endif; ?>
            
            <form method="GET" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="fecha">Buscar informes por fecha:</label>
                        <input type="date" name="fecha" id="fecha" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="buscar">Buscar</button>
                    </div>
                </div>
            </form>

            <div class="box-button">
                <form method="GET" action="" style="margin-top: 10px;">
                    <button type="submit" name="mostrar_informes" class="btn-todas">Todos los informes</button>
                    <button type="submit" name="mostrar_pendientes" class="btn-danger">Pendientes</button>
                    <button type="submit" name="mostrar_resueltos" class="btn-success">Resueltos</button>
                </form>
            </div>

            <div class="details-grid">
                <h3 class="title-h3">Últimos informes <?php echo htmlspecialchars($_SESSION['nombre_vivienda']); ?></h3>
                <div class="cards-container-scroll">
                    <?php if (!empty($informes)): ?>
                        <?php foreach ($informes as $informe): ?>
                            <div class="detail-group ">
                                <div class="grid-container ">
                                    <div class="grid-item ">
                                        <h5>Título:</h5>
                                        <p class="titulo-informe"><?php echo htmlspecialchars($informe['titulo']); ?></p>
                                    </div>
                                    <div class="grid-item">
                                        <h5>Usuario asociado:</h5>
                                        <p><?php echo htmlspecialchars($informe['nombre_usuario']); ?></p>
                                    </div>
                                    <div class="grid-item">
                                        <h5>Fecha de informe:</h5>
                                        <p><?php echo htmlspecialchars($informe['fecha_informe']); ?></p>
                                    </div>
                                    <div class="grid-item">
                                        <button class="btn-delete" onclick="mostrarModal(<?php echo $informe['id_informe_usuario']; ?>)" title="Eliminar informe">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-group">
                                <strong>Monitor de informe:</strong>
                                <p><?php echo htmlspecialchars($informe['nombre_responsable']); ?></p>
                            </div>

                            <div class="detail-group">
                                <strong class="descripcion">Descripción de informe:</strong>
                                <p><?php echo htmlspecialchars($informe['descripcion']); ?></p>
                            </div>

                            <form method="POST" action="" id="form-<?php echo $informe['id_informe_usuario']; ?>" onsubmit="cambiarEstado(event, this)">
                                <input type="hidden" name="id_informe" value="<?php echo $informe['id_informe_usuario']; ?>">
                                <input type="hidden" name="estado" value="<?php echo $informe['estado']; ?>" id="estado-<?php echo $informe['id_informe_usuario']; ?>"> 
                                <button type="submit" class="<?php 
                                    echo ($informe['estado'] === 'pendiente') ? 'btn-danger' : 'btn-success'; 
                                ?> mt-2" id="btn-<?php echo $informe['id_informe_usuario']; ?>">
                                    Informe <?php 
                                    echo ($informe['estado'] === 'pendiente') ? 'Pendiente' : 'Resuelto'; 
                                    ?>
                                </button>
                            </form>

                            <hr> 
                            
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No se encontraron informes.</p>
                    <?php endif; ?>

                    <div id="overlay" class="overlay"></div>
                    <div id="confirmModal" class="modal">
                        <div class="modal-content">
                            <h3>¿Estás seguro de que deseas eliminar este informe?</h3>
                            <p>Esta acción no se puede deshacer.</p>
                            <button class="cancel-btn" onclick="cerrarModal()">Cancelar</button>
                            <form method="POST" action="" id="deleteForm">
                                <input type="hidden" name="eliminar_informe" id="idinforme">
                                <button type="submit" class="confirm-btn">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

</body>
</html>
