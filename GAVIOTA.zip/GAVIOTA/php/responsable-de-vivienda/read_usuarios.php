<?php
/* Este script muestra los detalles de los usuarios asociados al responsable actual, obteniéndolos
de la base de datos tras validar su sesión.  */
session_start();

require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php'); 
    exit;
}

$conn = conectar_bd();
if (!$conn ) {
    die("Error en la conexión a la base de datos.");
}

$id_responsable = $_SESSION['user_id'];

function obtenerViviendaResponsable($conn, $id_responsable) {
    $sql = "SELECT v.id_vivienda, v.nombre_vivienda 
            FROM vivienda v
            JOIN responsable r ON v.id_vivienda = r.id_vivienda
            WHERE r.id_responsable = :id_responsable";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_responsable', $id_responsable, PDO::PARAM_INT);
    $stmt->execute();

    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function obtenerUsuariosAsociados($conn, $id_responsable) {
    $sql = "SELECT u.* 
            FROM usuario u
            JOIN vivienda v ON u.id_vivienda = v.id_vivienda
            JOIN responsable r ON v.id_vivienda = r.id_vivienda
            WHERE r.id_responsable = :id_responsable";

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_responsable', $id_responsable);
    $stmt->execute();

    return $stmt->fetchAll();
}

$vivienda = obtenerViviendaResponsable($conn, $id_responsable);

if ($vivienda) {
    $nombre_vivienda = $vivienda['nombre_vivienda'];
} else {
    $nombre_vivienda = "No hay vivienda asociada al responsable.";
}

$usuarios = obtenerUsuariosAsociados($conn, $id_responsable);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/read_responsable.css">
</head>

<body>
    <div class="container-fluid">
        <main>
            <div class="form-section">
                <h3 class="title-h3">Usuarios de la vivienda <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?></h3>
                <?php if (!empty($usuarios)): ?>
                    <ul class="cards-container">
                        <?php foreach ($usuarios as $usuario): ?>
                            <div class="container mt-5">
                                <div class="card">
                                    <h5 class="card-header titulo-h5"><?php echo htmlspecialchars($usuario['nombre_usuario']); ?></h5>
                                    <div class="card-body-usuarios">
                                        <div>
                                            <p class="card-text"><b>Situación personal:</b> <?php echo htmlspecialchars($usuario['situacion_personal']); ?></p>
                                            <p class="card-text"><b>Fecha de Nacimiento:</b> <?php echo htmlspecialchars($usuario['fecha_nacimiento']); ?></p>
                                            <p class="card-text"><b>Teléfono:</b> <?php echo htmlspecialchars($usuario['telefono']); ?></p>
                                            <p class="card-text"><b>Email:</b> <?php echo htmlspecialchars($usuario['email']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No se encontraron usuarios asociados al responsable.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
