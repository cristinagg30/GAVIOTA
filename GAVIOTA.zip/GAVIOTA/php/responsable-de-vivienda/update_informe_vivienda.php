<?php
/* Este script gestiona las informes relacionadas con la vivienda acosiada al responsable logueado.
Permite al responsable visualizar las informes, eliminarlas y actualizar el estado de ellas.
También permite buscar incicencias por fechas y filtrar por su estado */

session_start();

require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn ) {
    die("Error en la conexión a la base de datos.");
}

$alertEliminar= "";
$alertActualizado="";
$mensaje = "";

function eliminar_informe($conn, $id_informe) {
    try {
        $sql = "DELETE FROM informe_vivienda WHERE id_informe_vivienda = :id_informe";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_informe', $id_informe);
        return $stmt->execute();
    } catch (PDOException $e) {
        error_log("Error al eliminar la informe: " . $e->getMessage());
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['eliminar_informe'])) {
    $id_informe = $_POST['eliminar_informe'];

    if (eliminar_informe($conn, $id_informe)) {
        $alertEliminar = "Informe eliminado correctamente.";
    } else {
        $alertEliminar= "Error al eliminar la informe.";
    }
}

function obtenerViviendaResponsable($conn, $idUsuario) {
    $sql = "SELECT v.id_vivienda, v.nombre_vivienda 
            FROM responsable r
            JOIN vivienda v ON r.id_vivienda = v.id_vivienda
            WHERE r.id_responsable = :id_usuario";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_usuario', $idUsuario);
    $stmt->execute();
    return $stmt->fetch();
}

function obtenerinformes($conn, $idVivienda, $fechaSeleccionada = null, $soloPendientes = false, $soloresueltos = false, $mostrarTodas = false) {
    $sql = "SELECT iv.*, r.nombre_responsable 
            FROM informe_vivienda iv 
            JOIN responsable r ON iv.id_responsable = r.id_responsable 
            WHERE iv.id_vivienda = :id_vivienda";

    if ($fechaSeleccionada) {
        $sql .= " AND iv.fecha_informe = :fecha_informe";
    }

    if ($soloPendientes) {
        $sql .= " AND iv.estado = 'pendiente'";
    }

    if ($soloresueltos) {
        $sql .= " AND iv.estado = 'resuelto'";
    }

    $sql .= " ORDER BY iv.fecha_informe DESC";
    
    if (!$mostrarTodas && !$soloPendientes && !$soloresueltos) {
        $sql .= " LIMIT 7";
    }

    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_vivienda', $idVivienda);
    
    if ($fechaSeleccionada) {
        $stmt->bindParam(':fecha_informe', $fechaSeleccionada);
    }

    $stmt->execute();
    return $stmt->fetchAll();
}

function actualizarEstadoinforme($conn, $idinforme, $nuevoEstado) {
    $sql = "UPDATE informe_vivienda SET estado = :estado WHERE id_informe_vivienda = :id_informe_vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':estado', $nuevoEstado);
    $stmt->bindParam(':id_informe_vivienda', $idinforme);
    
    return $stmt->execute();
}

if (!isset($_SESSION['id_vivienda']) || !isset($_SESSION['nombre_vivienda'])) {
    $idUsuario = $_SESSION['user_id'];
    $resultado = obtenerViviendaResponsable($conn, $idUsuario);

    if ($resultado) {
        $_SESSION['id_vivienda'] = $resultado['id_vivienda'];
        $_SESSION['nombre_vivienda'] = $resultado['nombre_vivienda'];
    } else {
        $mensaje = "No se encontró la vivienda asociada al usuario.";
    }
}

$informes = [];
$fechaSeleccionada = isset($_GET['fecha']) ? $_GET['fecha'] : null; 
$mostrarBoton = false; 

$soloPendientes = isset($_GET['mostrar_pendientes']) ? true : false; 
$soloresueltos = isset($_GET['mostrar_resueltos']) ? true : false;
$mostrarTodas = isset($_GET['mostrar_informes']) ? true : false;

if (!empty($_SESSION['id_vivienda']) && $_SERVER["REQUEST_METHOD"] === "GET") {
    $idVivienda = $_SESSION['id_vivienda'];

    $informes = obtenerinformes($conn, $idVivienda, $fechaSeleccionada, $soloPendientes, $soloresueltos, $mostrarTodas);

    if (!empty($informes)) {
        $mostrarBoton = true;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['id_informe']) && isset($_POST['estado'])) {
    $idinforme = $_POST['id_informe'];
    $nuevoEstado = $_POST['estado'];

    if (actualizarEstadoinforme($conn, $idinforme, $nuevoEstado)) {
        $alertActualizado = "Estado del informe actualizado correctamente.";
    } else {
        $mensaje = "Error al actualizar el estado.";
    }

    $informes = obtenerinformes($conn, $_SESSION['id_vivienda'], null, $soloPendientes, $soloresueltos, $mostrarTodas);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de informes de Vivienda</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/update_responsable.css">
</head>

<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Gestión de la vivienda <p class="nom-vivienda"><?php echo htmlspecialchars($_SESSION['nombre_vivienda']); ?></p></h3>
            <?php if (!empty($alertEliminar) || !empty($alertActualizado)): ?>
                <div class="alert">
                    <h4>
                        <?php if (!empty($alertEliminar)): ?>
                            <i class="bi bi-check2-circle"></i> <?php echo $alertEliminar; ?>
                        <?php endif; ?>
                        <?php if (!empty($alertActualizado)): ?>
                            <i class="bi bi-check2-circle"></i> <?php echo $alertActualizado; ?>
                        <?php endif; ?>
                    </h4>
                </div>
            <?php endif; ?>

            <?php if ($mensaje) { echo "<p>$mensaje</p>"; } ?>
            <form method="GET" action="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="fecha">Buscar informes por Fecha:</label>
                        <input type="date" name="fecha" id="fecha" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="buscar">Buscar</button>
                    </div>
                </div>
            </form>

            <div class="box-button">
            <form method="GET" action="" >
                <button type="submit" name="mostrar_informes" class="btn-todas">Todos los informes</button>
                <button type="submit" name="mostrar_pendientes" class="btn-danger">Pendiente</button>
                <button type="submit" name="mostrar_resueltos" class=" btn-success">Resuelto</button>
            </form>
            </div>

            <div class="details-grid">
                <h3 class="title-h3">Últimos informes <?php echo htmlspecialchars($_SESSION['nombre_vivienda']); ?></h3></h3> </h1>
                <div class="cards-container-scroll">
                    <?php if (!empty($informes)): ?>
                        <?php foreach ($informes as $informe): ?>
                            <div class="section">
                                <div class="grid-container">
                                    <div class="grid-item">
                                        <h5 >Título:</h5>
                                        <p class="titulo-informe"><?php echo htmlspecialchars($informe['titulo']); ?></p>
                                    </div>
                                    <div class="grid-item">
                                <h5>Responsable: </h5>
                                <p><?php echo htmlspecialchars($informe['nombre_responsable']); ?></p>
                                </div>
                                    <div class="grid-item">
                                        <h5>Fecha de informe: </h5>
                                        <p><?php echo htmlspecialchars($informe['fecha_informe']); ?></p>
                                    </div>
                                    <div class="grid-item">
                                    <button class="btn-delete" onclick="mostrarModal(<?php echo $informe['id_informe_vivienda']; ?>)" title="Eliminar informe">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                    </div>
                                </div>
                            </div>

                            <div class="detail-group">
                                <h5>Descripción de informe:</h5>
                                <p><?php echo htmlspecialchars($informe['descripcion']); ?></p>
                            </div>
                            <form method="POST" action="" id="form-<?php echo $informe['id_informe_vivienda']; ?>" onsubmit="cambiarEstado(event, this)">
                                        <input type="hidden" name="id_informe" value="<?php echo $informe['id_informe_vivienda']; ?>">
                                        <input type="hidden" name="estado" value="<?php echo $informe['estado']; ?>" id="estado-<?php echo $informe['id_informe_vivienda']; ?>"> 

                                        <button type="submit" class=" <?php echo ($informe['estado'] === 'pendiente') ? 'btn-danger' : 'btn-success'; ?> mt-2" id="btn-<?php echo $informe['id_informe_vivienda']; ?>">
                                            Informe <?php echo ($informe['estado'] === 'pendiente') ? 'Pendiente' : 'resuelto'; ?>
                                        </button>
                                    </form>


                            <hr> 
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No se encontraron informes.</p>
                    <?php endif; ?>

                    <div id="overlay" class="overlay"></div>
                    <div id="confirmModal" class="modal">
                        <div class="modal-content">
                            <h3>¿Estás seguro de que deseas eliminar este informe?</h3>
                            <p>Esta acción no se puede deshacer.</p>
                            <button class="cancel-btn" onclick="cerrarModal()">Cancelar</button>
                            <form method="POST" action="" id="deleteForm">
                                <input type="hidden" name="eliminar_informe" id="idinforme">
                                <button type="submit" class="confirm-btn">Eliminar</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>

<script>


function cambiarEstado(event, form) {
    event.preventDefault();

    var estadoActual = form.estado.value;
    var idinforme = form.id_informe.value;
    var boton = document.getElementById('btn-' + idinforme);
    var estadoField = document.getElementById('estado-' + idinforme);

    if (estadoActual === 'pendiente') {
        boton.textContent = 'informe resuelto';
        boton.classList.remove('btn-danger');
        boton.classList.add('btn-success');
        estadoField.value = 'resuelto';
    } else {
        boton.textContent = 'informe Pendiente';
        boton.classList.remove('btn-success');
        boton.classList.add('btn-danger');
        estadoField.value = 'pendiente';
    }

    form.submit();
        function mostrarModal(idinforme) {
            document.getElementById('idinforme').value = idinforme; 
            document.getElementById('confirmModal').style.display = 'flex';
            document.getElementById('overlay').style.display = 'block';
        }

        function cerrarModal() {
            document.getElementById('confirmModal').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        }

        function confirmarEliminacion() {
            document.getElementById('eliminarForm').submit();
        }
}

    function mostrarModal(idinforme) {
            document.getElementById('idinforme').value = idinforme; 
            document.getElementById('confirmModal').style.display = 'flex';
            document.getElementById('overlay').style.display = 'block';
        }

        function cerrarModal() {
            document.getElementById('confirmModal').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        }

        function confirmarEliminacion() {
            document.getElementById('eliminarForm').submit();
        }
</script>

</body>
</html>
