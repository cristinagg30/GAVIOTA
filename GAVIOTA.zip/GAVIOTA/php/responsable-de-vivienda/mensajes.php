<?php
/* Este script permite enviar mensajes tanto a los demás responsables como al director y muestra los que
recibe el responsable logeado */
session_start();
require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

$query = "SELECT id_responsable, nombre_responsable FROM responsable";
$stmt = $conn->prepare($query);
$stmt->execute();
$responsables = $stmt->fetchAll();

$query_director = "SELECT id_director, nombre_director FROM director";
$stmt_director = $conn->prepare($query_director);
$stmt_director->execute();
$director = $stmt_director->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['destinatario'], $_POST['mensaje'])) {
    $id_remitente = $_SESSION['user_id'];  
    $id_destinatario = $_POST['destinatario'];
    $mensaje = $_POST['mensaje'];

    if ($_POST['destinatario'] == 'director') {
        $sql = "INSERT INTO mensajes (id_remitente_responsable, id_destinatario_director, mensaje) 
                VALUES (:id_remitente, :id_destinatario, :mensaje)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':id_remitente' => $id_remitente,
            ':id_destinatario' => $director['id_director'],
            ':mensaje' => $mensaje
        ]);
    } else {
        $sql = "INSERT INTO mensajes (id_remitente_responsable, id_destinatario_responsable, mensaje) 
                VALUES (:id_remitente, :id_destinatario, :mensaje)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':id_remitente' => $id_remitente,
            ':id_destinatario' => $id_destinatario,
            ':mensaje' => $mensaje
        ]);
    }
    $mensaje_exito = "Mensaje enviado con éxito.";
}

$id_responsable = $_SESSION['user_id']; 

if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
    $id_mensaje = $_GET['eliminar'];

    $sql = "DELETE FROM mensajes WHERE id_mensaje = :id_mensaje AND 
            (id_destinatario_responsable = :id_responsable OR id_destinatario_director = :id_responsable)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id_mensaje' => $id_mensaje, ':id_responsable' => $id_responsable]);

    $mensaje_exito = "Mensaje eliminado con éxito.";

    header("Location: mensajes.php");
    exit;  
}

if (isset($_GET['marcar_leido']) && is_numeric($_GET['marcar_leido'])) {
    $id_mensaje = $_GET['marcar_leido'];

    $sql = "UPDATE mensajes SET leido = NOT leido WHERE id_mensaje = :id_mensaje 
            AND (id_destinatario_responsable = :id_responsable OR id_destinatario_director = :id_responsable)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id_mensaje' => $id_mensaje, ':id_responsable' => $id_responsable]);

    $mensaje_exito = "Estado del mensaje actualizado.";

    header("Location: mensajes.php");
    exit; 
}

$query_no_leidos = "SELECT COUNT(*) AS total_no_leidos 
                    FROM mensajes 
                    WHERE (id_destinatario_responsable = :id_responsable OR id_destinatario_director = :id_responsable)
                    AND leido = 0";
$stmt_no_leidos = $conn->prepare($query_no_leidos);
$stmt_no_leidos->execute([':id_responsable' => $id_responsable]);
$no_leidos = $stmt_no_leidos->fetch();
$total_no_leidos = $no_leidos['total_no_leidos'];

$query_mensajes = "SELECT m.id_mensaje, m.id_remitente_responsable, m.mensaje, m.fecha_envio, m.leido, 
        r.nombre_responsable AS remitente_nombre, d.nombre_director AS director_nombre 
    FROM mensajes m
    LEFT JOIN responsable r ON m.id_remitente_responsable = r.id_responsable
    LEFT JOIN director d ON m.id_remitente_director = d.id_director
    WHERE (m.id_destinatario_responsable = :id_responsable OR m.id_destinatario_director = :id_responsable)
    ORDER BY m.fecha_envio DESC";
$stmt_mensajes = $conn->prepare($query_mensajes);
$stmt_mensajes->execute([':id_responsable' => $id_responsable]);
$mensajes = $stmt_mensajes->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enviar Mensaje</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/mensajes_r.css">
</head>
<body>
    
    <div class="container-fluid">
        <main>
        <div class="form-section">  
            <h3 class="title-h3">Mensajes</h3>

            <?php if (isset($mensaje_exito)): ?>
                <div class="alert alert-success"><i class="bi bi-check2-circle"></i><?php echo $mensaje_exito; ?></div>
            <?php endif; ?>
            <h5 class="titulo-h5">Enviar mensajes</h5>
            <form method="POST">
                <div class="form-group">
                    <label for="destinatario">Seleccionar Destinatario:</label>
                    <select name="destinatario" id="destinatario" required>
                        <option value="" disabled selected>Seleccionar destinatario</option>
                        <optgroup label="Director">
                            <option value="director"><?php echo htmlspecialchars($director['nombre_director']); ?></option>
                        </optgroup>
                        <optgroup label="Responsables">
                            <?php foreach ($responsables as $responsable): ?>
                                <option value="<?php echo $responsable['id_responsable']; ?>">
                                    <?php echo htmlspecialchars($responsable['nombre_responsable']); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                    </select>
                </div>

                <div class="form-group">
                    <label for="mensaje">Mensaje:</label>
                    <textarea name="mensaje" id="mensaje" rows="10" required></textarea>
                </div>

                <button type="submit" class="boton">Enviar Mensaje</button>
            </form>

            <h5 class="titulo-h5 recibidos">Mensajes Recibidos
                <div class="notificaciones-circulo">
                    <?php if ($total_no_leidos > 0): ?>
                        <div class="circle-notification">
                            <?php echo $total_no_leidos; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </h5>
            <div class="mensajes">
                <?php if (count($mensajes) > 0): ?>
                    <div class="mensaje-lista">
                        <?php foreach ($mensajes as $mensaje): ?>
                            <div class="mensaje-item">
                                <div class="columna remitente">
                                    <strong>Remitente:</strong> 
                                    <?php 
                                    echo htmlspecialchars($mensaje['remitente_nombre'] ?: $mensaje['director_nombre']); 
                                    ?>
                                </div>
                                <div class="columna estado">
                                    <strong>Estado:</strong> 
                                    <?php if ($mensaje['leido'] == 1): ?>
                                        <span class="badge badge-leido">Leído</span>
                                    <?php else: ?>
                                        <span class="badge badge-no-leido">No leído</span>
                                    <?php endif; ?>
                                </div>
                                <div class="columna enviado">
                                    <strong>Enviado el:</strong> <?php echo $mensaje['fecha_envio']; ?>
                                </div>
                                <div class="mensaje">
                                    <strong>Mensaje:</strong>
                                    <p><?php echo htmlspecialchars($mensaje['mensaje']); ?></p>
                                </div>
                                <div class="acciones">
                                    <a href="?marcar_leido=<?php echo $mensaje['id_mensaje']; ?>" class="btn btn-info">
                                        <?php echo $mensaje['leido'] == 1 ? 'Marcar como no leído' : 'Marcar como leído'; ?>
                                    </a>
                                    <a href="?eliminar=<?php echo $mensaje['id_mensaje']; ?>" class="btn btn-danger" onclick="return confirm('¿Seguro que deseas eliminar este mensaje?');">Eliminar</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No tienes mensajes.</p>
                <?php endif; ?>
            </div>
        </div>
        </main>
    </div>
</body>
</html>
