<?php
/* Este Script permite a los responsables gestionar informes de las viviendas asociadas mediante un formulario.*/
session_start();

require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php'); 
    exit;
}

$conn = conectar_bd(); 
if (!$conn ) {
    die("Error en la conexión a la base de datos.");
}

$fecha_actual = date('Y-m-d');

$registroExito = ''; 

function obtenerNombreResponsable($conn , $id_responsable) {
    $query = "SELECT nombre_responsable FROM responsable WHERE id_responsable = :id_responsable"; 
    try {
        $stmt = $conn ->prepare($query); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute(); 
        return $stmt->fetchColumn();
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return null; 
    }
}

$id_responsable = $_SESSION['user_id'];
$nombre_responsable = obtenerNombreResponsable($conn , $id_responsable);
$_SESSION['nombre_responsable'] = $nombre_responsable;

function obtenerViviendaResponsable($conn , $id_responsable) {
    $query = "SELECT v.id_vivienda, v.nombre_vivienda 
            FROM vivienda v
            INNER JOIN responsable r ON v.id_vivienda = r.id_vivienda 
            WHERE r.id_responsable = :id_responsable"; 
    try {
        $stmt = $conn ->prepare($query); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute(); 
        return $stmt->fetch();
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return null;
    }
}

$vivienda = obtenerViviendaResponsable($conn, $id_responsable);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['estado']) || empty($_POST['vivienda']) || empty($_POST['titulo']) || empty($_POST['descripcion']) || empty($_POST['fechainforme'])) {
        echo "Debe rellenar todos los campos.";
        exit;
    }

    $id_vivienda = $_POST['vivienda']; 
    $id_responsable = $_SESSION['user_id']; 
    $titulo = $_POST['titulo']; 
    $descripcion = $_POST['descripcion']; 
    $fecha_informe = $_POST['fechainforme'] ?? date('Y-m-d');
    $estado = $_POST['estado']; 

    $query = "INSERT INTO informe_vivienda (id_vivienda, id_responsable, titulo, descripcion, fecha_informe, estado) 
            VALUES (:id_vivienda, :id_responsable, :titulo, :descripcion, :fecha_informe, :estado)";
    
    try {
        $stmt = $conn ->prepare($query);
        $stmt->bindParam(':id_vivienda', $id_vivienda);
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->bindParam(':titulo', $titulo);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':fecha_informe', $fecha_informe);
        $stmt->bindParam(':estado', $estado);

        $stmt->execute();
        $registroExito = 'Informe de la vivienda registrado con éxito';
    } catch (PDOException $e) {
        echo "Error al registrar la informe: " . $e->getMessage();
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/create_responsable.css">
</head>


<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Nuevo informe de vivienda</h3>
                <?php if (!empty($registroExito)): ?>
                    <div class="alert">
                    <h4><i class="bi bi-check2-circle"></i> <?php echo $registroExito; ?></h4>
                    </div>
                <?php endif; ?>

            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="form-grid">
                <div class="form-group">
                    <label for="vivienda">Vivienda:</label>
                    <select id="vivienda" name="vivienda">
                    <?php
                    if ($vivienda) { 
                        echo "<option value='" . $vivienda['id_vivienda'] . "'>" . $vivienda['nombre_vivienda'] . "</option>";
                    } else {
                        echo "<option>No hay viviendas disponibles</option>";
                    }
                    ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="nombre-monitor">Nombre monitor:</label>
                    <input type="text" id="nombre-monitor" name="nombre-monitor" value="<?php echo htmlspecialchars($_SESSION['nombre_responsable']); ?>" required readonly>
                </div>

                <div class="form-group">
                    <label for="fechainforme">Fecha informe:</label>
                    <input type="date" id="fechainforme" name="fechainforme" value="<?php echo $fecha_actual; ?>" readonly>
                </div>

                <div class="form-group">
                    <label for="titulo">Titulo informe:</label>
                    <input type="text" id="titulo" name="titulo" required>
                </div>

                <div class="form-group">
                    <label for="estadoinforme">Estado del informe:</label>
                    <select id="estadoinforme" name="estado" required>
                        <option value="pendiente">Pendiente</option>
                        <option value="resuelto">Resuelto</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="descripcion">Descripción:</label>
                    <textarea id="descripcion" name="descripcion" rows="5" cols="50" required></textarea>
                </div>

                <button type="submit" class="boton">Registrar informe vivienda</button>
            </form>
        </div>
    </main>
</div>

</body>
</html>
