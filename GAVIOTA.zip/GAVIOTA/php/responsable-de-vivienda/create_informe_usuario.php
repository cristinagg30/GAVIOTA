<?php
/* Este Script permite a los responsables gestionar informes de usuarios asociados mediante un formulario. 
Verifica la autenticación del responsable, obtiene datos de la vivienda y usuarios asociados, 
y registra las informes en la base de datos */
session_start();

require '../bd.php';
require_once 'general_responsable.php';

$fecha_actual = date('Y-m-d');
$registroExito = '';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php'); 
    exit;
}

$conn = conectar_bd(); 
if (!$conn ) {
    die("Error en la conexión a la base de datos.");
}


function obtenerNombreResponsable($conn, $id_responsable) {
    $query = "SELECT nombre_responsable FROM responsable WHERE id_responsable = :id_responsable"; 
    try {
        $stmt = $conn->prepare($query); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute(); 
        return $stmt->fetchColumn(); 
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return null; 
    }
}

$id_responsable = $_SESSION['user_id'];
$nombre_responsable = obtenerNombreResponsable($conn, $id_responsable);
$_SESSION['nombre_responsable'] = $nombre_responsable;

function obtenerViviendaResponsable($conn, $id_responsable) {
    $query = "SELECT vivienda.id_vivienda, vivienda.nombre_vivienda 
            FROM vivienda 
            INNER JOIN responsable ON vivienda.id_vivienda = responsable.id_vivienda 
            WHERE responsable.id_responsable = :id_responsable"; 
    try {
        $stmt = $conn->prepare($query); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute(); 
        return $stmt->fetch(); 
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return null;
    }
}

$vivienda = obtenerViviendaResponsable($conn, $id_responsable);


function obtenerUsuariosAsociados($conn, $id_responsable) {
    $query = "SELECT usuario.id_usuario, usuario.nombre_usuario 
            FROM usuario 
            INNER JOIN vivienda ON usuario.id_vivienda = vivienda.id_vivienda 
            INNER JOIN responsable ON vivienda.id_vivienda = responsable.id_vivienda 
            WHERE responsable.id_responsable = :id_responsable";
    try {
        $stmt = $conn->prepare($query); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute(); 
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return [];
    }
}

$usuarios = obtenerUsuariosAsociados($conn, $id_responsable);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST['estado']) || empty($_POST['vivienda']) || empty($_POST['usuario']) || empty($_POST['titulo']) || empty($_POST['descripcion'])) {
        echo "Debe rellenar todos los campos.";
        exit;
    }
    
    $id_vivienda = $_POST['vivienda'];
    $id_usuario = $_POST['usuario']; 
    $id_responsable = $_SESSION['user_id']; 
    $titulo = trim($_POST['titulo']); 
    $descripcion = trim($_POST['descripcion']);
    $fecha_informe = $_POST['fechainforme'] ?? date('Y-m-d');
    $estado = $_POST['estado'];

    $query = "INSERT INTO informe_usuario (id_vivienda, id_usuario, id_responsable, titulo, descripcion, fecha_informe, estado) 
            VALUES (:id_vivienda, :id_usuario, :id_responsable, :titulo, :descripcion, :fecha_informe, :estado)";
    try {
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id_vivienda', $id_vivienda);
        $stmt->bindParam(':id_usuario', $id_usuario ); 
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->bindParam(':titulo', $titulo);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':fecha_informe', $fecha_informe);
        $stmt->bindParam(':estado', $estado);

        $stmt->execute();
        $registroExito = 'Informe del usuario registrado con éxito';
    
    } catch (PDOException $e) {
        echo "Error al registrar la informe: " . $e->getMessage();
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/create_responsable.css">

</head>

<body>
    <div class="container-fluid">
        <main>
                <div class="form-section">
                    <h3 class="title-h3">Registro informe de los Usuarios</h3>
                    
                    <?php if (!empty($registroExito)): ?>
                        <div class="alert">
                            <h4><i class="bi bi-check2-circle"></i><?php echo $registroExito; ?></h4>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="form-grid">
                        <div class="form-group">
                            <label for="vivienda">Vivienda:</label>
                                <select id="vivienda" name="vivienda">
                                    <?php
                                    if ($vivienda) {
                                        echo "<option value='" . $vivienda['id_vivienda'] . "'>" . $vivienda['nombre_vivienda'] . "</option>";
                                    } else {
                                        echo "<option>No hay viviendas disponibles</option>";
                                    }
                                    ?>
                                </select>
                        </div>

                        <div class="form-group">
                            <label for="nombre-monitor">Nombre Responsable:</label>
                            <input type="text" id="nombre-monitor" name="nombre-monitor" value="<?php echo htmlspecialchars($_SESSION['nombre_responsable']); ?>" required readonly>
                        </div>

                        <div class="form-group">
                            <label for="usuario">Nombre usuario:</label>
                            <select id="usuario" name="usuario">
                                <?php
                                    if ($usuarios) { 
                                        foreach ($usuarios as $usuario) {
                                            echo "<option value='" . $usuario['id_usuario'] . "'>" . htmlspecialchars($usuario['nombre_usuario']) . "</option>";
                                        }
                                    } else {
                                        echo "<option>No hay usuarios disponibles</option>";
                                    }
                                ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="fechainforme">Fecha informe:</label>
                            <input type="date" id="fechainforme" name="fechainforme" value="<?php echo $fecha_actual; ?>" readonly>
                        </div>

                        <div class="form-group">
                            <label for="titulo">Titulo informe:</label>
                            <input type="text" id="titulo" name="titulo" required>
                        </div>

                        <div class="form-group">
                            <label for="estadoinforme">Estado del informe:</label>
                            <select id="estadoinforme" name="estado">
                                <option value="pendiente">Pendiente</option>
                                <option value="resuelto">Resuelto</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="descripcion">Descripción:</label>
                            <textarea id="descripcion" name="descripcion" rows="5" cols="50" required></textarea>
                        </div>

                        <button type="submit" class="boton">Registrar informe usuario</button>
                    </form>
                </div>
        </main>
    </div>
</body>
</html>

