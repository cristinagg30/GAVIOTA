<?php
/* Este script muestra los detalles de la vivienda asociada al responsable actual, obteniéndolos
de la base de datos tras validar su sesión. Utiliza una consulta SQL para buscar información
específica de la vivienda y los usuarios asociados, y los presenta en una tarjeta con detalles como dirección, 
información adicional y usuarios asociados. Si no se encuentra una vivienda, informa al usuario mediante un mensaje. */
session_start();

require '../bd.php';
require_once 'general_responsable.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'responsable') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn ) {
    die("Error en la conexión a la base de datos.");
}

$id_responsable = $_SESSION['user_id'];

function obtenerViviendaDelResponsable($conn, $id_responsable) {
    $sql = "SELECT id_vivienda FROM responsable WHERE id_responsable = :id_responsable";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_responsable', $id_responsable);
    $stmt->execute();
    return $stmt->fetch();
}

function obtenerInformacionVivienda($conn, $id_vivienda) {
    $sql = "SELECT * FROM vivienda WHERE id_vivienda = :id_vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_vivienda', $id_vivienda);
    $stmt->execute();
    return $stmt->fetch();
}

function obtenerUsuariosPorVivienda($conn, $id_vivienda) {
    $sql = "SELECT * FROM usuario WHERE id_vivienda = :id_vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id_vivienda', $id_vivienda);
    $stmt->execute();
    return $stmt->fetchAll();
}


$vivienda = obtenerViviendaDelResponsable($conn, $id_responsable);

if ($vivienda) {
    $id_vivienda = $vivienda['id_vivienda'];

    $vivienda_detalle = obtenerInformacionVivienda($conn, $id_vivienda);

    $usuarios = obtenerUsuariosPorVivienda($conn, $id_vivienda);
} else {
    $vivienda_detalle = null;
    $usuarios = [];
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/read_responsable.css">
</head>

<body>
    <div class="container-fluid">
        <main>
            <div class="form-section">
                <h3 class="title-h3">Información de vivienda</h3>
                <?php if ($vivienda_detalle): ?>
                    <div class="card">
                        <h5 class="card-header titulo-h5"><b>Vivienda:</b> <?php echo htmlspecialchars($vivienda_detalle['nombre_vivienda']); ?> </h5>
                        <div class="card-body cards-container">
                                <p class="card-text"><B>Dirección:</B></p>
                                <p>
                                    C/<?php echo htmlspecialchars($vivienda_detalle['calle']) . ' ' . 
                                        htmlspecialchars($vivienda_detalle['numero']) . ', ' . 
                                        htmlspecialchars($vivienda_detalle['piso']) . ', ' . 
                                        htmlspecialchars($vivienda_detalle['ciudad']). ', ' . 
                                        htmlspecialchars($vivienda_detalle['provincia']). ', ' . 
                                        htmlspecialchars($vivienda_detalle['codigo_postal']); ?>
                                </p>                                                  
                                <p class="card-text"><b>Información vivienda:</b></p> 
                                <p><?php echo htmlspecialchars($vivienda_detalle['informacion']); ?></p>
                                <p class="card-text"><B>Usuarios de la vivienda:</B></p>
                            <?php if (!empty($usuarios)): ?>
                                <ul>
                                    <?php foreach ($usuarios as $usuario): ?>
                                        <li>
                                            <div class="">
                                                <p><b><?php echo htmlspecialchars($usuario['nombre_usuario']); ?> </b>| <?php echo htmlspecialchars($usuario['telefono']); ?> | <?php echo htmlspecialchars($usuario['email']); ?></p>
                                                
                                            </div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p>No se encontraron usuarios asociados a esta vivienda.</p>
                            <?php endif; ?>
                            <?php else: ?>
                                <p>No se encontró una vivienda asociada al responsable.</p>
                            <?php endif; ?>
                        </div>
                    </div>
            </div>
        </main>
    </div>
</body>
</html>
