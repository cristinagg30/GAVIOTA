
<!DOCTYPE html>
<!-- Menú lateral del rol del responsable -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/nav_responsable.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</head>
<body>
    <button class="sidebar-toggle" aria-label="Abrir menú">
        <i class="bi bi-list"></i> 
    </button>

    <nav class="sidebar">
        <h2>Panel de Control del Responsable</h2>
        <ul>
            <li class="menu-item">Vivienda <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="read_vivienda.php">Información de Vivienda</a></li>
                    <li><a href="create_informe_vivienda.php">Nuevo informe de vivienda</a></li>
                    <li><a href="update_informe_vivienda.php">Gestión de la vivienda</a></li>
                </ul>
            </li>
            <li class="menu-item">Usuarios <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="read_usuarios.php">Información de Usuarios</a></li>
                    <li><a href="create_informe_usuario.php">Registro informe de Usuarios</a></li>
                    <li><a href="update_informe_usuario.php">Gestión de Usuarios</a></li>
                </ul>
            </li>
            <li class="menu-item">Mi perfil <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="perfil_responsable.php">Mostrar mi perfil</a></li>
                    <li><a href="mensajes.php">Mensajes</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const botonAlternar = document.querySelector('.sidebar-toggle');
            const barraLateral = document.querySelector('.sidebar');

            botonAlternar.addEventListener('click', function () {
                barraLateral.classList.toggle('open');
            });

            document.querySelectorAll('.menu-item').forEach(function (itemMenu) {
                itemMenu.addEventListener('click', function (evento) {
                    evento.stopPropagation();

                    const subMenu = this.querySelector('.submenu');
                    const icono = this.querySelector('.bi-caret-down-fill');

                    if (subMenu) {
                        subMenu.classList.toggle('visible');
                        icono.classList.toggle('bi-caret-up-fill');
                    }
                });
            });
        });
    </script>

</body>
</html>
