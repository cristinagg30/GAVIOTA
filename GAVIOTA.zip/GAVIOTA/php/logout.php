<?php
/* Este script, cierra la sesión del usuario.
Destruye todos los datos almacenados de la sesión y luego elimina
la cookie que mantiene la sesión activa. Despues, redirige al usuario a la página de inicio de sesión.*/

    session_start(); 
    $_SESSION = array();
    session_destroy();
    setcookie(session_name(), 123, time()-1000); 
    header("Location: login.php"); 
    exit;
?>
