<?php
/* Este script controla el inicio de sesión a la App, donde los usuarios pueden autenticarse como
"director" o "responsable". Dependiendo del rol seleccionado, se verifica el correo y la clave en
la base de datos. Si es exitosa, se inicia sesión y se redirige al usuario a la página correspondiente
según su rol. En caso de error, se muestra un mensaje de error.  */

session_start();
require 'bd.php';

$error="";

    function login($conn, $useremail, $clave, $role) {
        if ($role === 'director') {
            $sql = "SELECT id_director, clave, nombre_director FROM director WHERE email = :email";
        } else if ($role === 'responsable') {
            $sql = "SELECT id_responsable, clave, nombre_responsable FROM responsable WHERE email = :email";
        } else {
            return false; 
        }

        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':email', $useremail); 
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $user = $stmt->fetch(); 

            if ($clave === $user['clave']) { 
                $_SESSION['user_id'] = $role === 'director' ? $user['id_director'] : $user['id_responsable'];
                $_SESSION['role'] = $role;

                if ($role === 'director') {
                    $_SESSION['nombre'] = $user['nombre_director']; 
                } else if ($role === 'responsable') {
                    $_SESSION['nombre'] = $user['nombre_responsable']; 
                }
                return true; 
            } else {
                return false; 
            }
        } else {
            return false; 
        }
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $useremail = $_POST['email'];
        $userclave = $_POST['clave'];
        $role = $_POST['role']; 

        $conn = conectar_bd();

        if (login($conn, $useremail, $userclave, $role)) {
            if ($role === 'director') {
                header('Location: director-de-viviendas/home_director.php');
            } else if ($role === 'responsable') {
                header('Location: responsable-de-vivienda/home_responsable.php');
            }
            exit; 
        } else {
            $error = "Usuario o contraseña incorrectos"; 
        }
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Gestión de Viviendas</title>
    <link rel="icon" href="../../img/gaviota.png" type="image/x-icon">
    <link rel="stylesheet" href="../css/login.css">
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    
</head>
<body class="login">
    <div class="login-container">
        <div class="logo">
            <img src="../img/gaviota.png" alt="Logo de Gestión de Viviendas">
            <h1><b>GAVIOTA</b></h1>
        </div>

        <div class="login-form">
            <h2>Iniciar Sesión</h2>
            <form action=" <?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <label for="role">Tipo de Usuario:</label>
                    <select name="role" required>
                        <option value="director">Director de Gestión de Viviendas</option>
                        <option value="responsable">Responsable de vivienda</option>
                    </select>
                <label for="email">Correo Electrónico:</label>
                <input name="email" type="text" placeholder="Introduce tu correo" value="" required>

                <label for="clave">Contraseña:</label>
                <input type="password" id="clave" name="clave" placeholder="Introduce tu contraseña" required>

                <button type="submit">Iniciar Sesión</button>

                <?php if ($error): ?>
                    <div class="alert alert-danger box-error" role="alert">
                    <i class="bi bi-hand-thumbs-down-fill"> </i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</body>
</html>
