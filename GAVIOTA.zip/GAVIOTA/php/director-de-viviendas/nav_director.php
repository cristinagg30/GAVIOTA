<!-- Este Script corresponde al menú lateral de la aplicación, 
    utilizado por el director para gestionar viviendas, usuarios, responsables y su perfil. -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../../css/responsable-de-vivienda/nav_responsable.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
</head>
<body>
    <button class="sidebar-toggle" aria-label="Abrir menú">
        <i class="bi bi-list"></i> 
    </button>

    <nav class="sidebar">
        <h2>Panel de Control del Director</h2>
        <ul>
            <li class="menu-item">Viviendas <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="read_viviendas.php">Información de las Viviendas</a></li>
                    <li><a href="add_viviendas_d.php">Añadir viviendas</a></li>
                    <li><a href="update_viviendas_d.php">Actualizar viviendas</a></li>
                    <li><a href="delete_vivienda_d.php">Eliminar viviendas</a></li>
                    <li><a href="mostrar_informe_vivienda.php">Mostrar informes de viviendas</a></li>
                </ul>
            </li>
            <li class="menu-item">Responsables <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="read_responsables.php">Información de los responsables</a></li>
                    <li><a href="add_responsable_d.php">Añadir Responsables</a></li>
                    <li><a href="update_responsable_d.php">Actualizar Responsables</a></li>
                    <li><a href="delete_responsable_d.php">Eliminar Responsables</a></li>
                </ul>
            </li>
            <li class="menu-item">Usuarios <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="read_usuarios.php">Información de Usuarios</a></li>
                    <li><a href="add_usuarios_d.php">Añadir Usuarios</a></li>
                    <li><a href="update_usuarios_d.php">Actualizar Usuarios</a></li>
                    <li><a href="delete_usuarios_d.php">Eliminar Usuarios</a></li>
                    <li><a href="mostrar_informe_usuario.php">Ver informes de Usuarios</a></li>
                </ul>
            </li>

            <li class="menu-item">Mi perfil <i class="bi bi-caret-down-fill"></i>
                <ul class="submenu">
                    <li><a href="perfil_director.php">Mostrar mi perfil</a></li>
                    <li><a href="mensajes_d.php">Mensajes</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const botonToggle = document.querySelector('.sidebar-toggle');
            const barraLateral = document.querySelector('.sidebar');

            botonToggle.addEventListener('click', function () {
                barraLateral.classList.toggle('open');
            });

            document.querySelectorAll('.menu-item').forEach(function (itemMenu) {
                itemMenu.addEventListener('click', function (evento) {
                    evento.stopPropagation();

                    const subMenu = this.querySelector('.submenu');
                    const icono = this.querySelector('.bi-caret-down-fill');

                    if (subMenu) {
                        subMenu.classList.toggle('visible');
                        icono.classList.toggle('bi-caret-up-fill');
                    }
                });
            });
        });
    </script>
</body>
</html>
