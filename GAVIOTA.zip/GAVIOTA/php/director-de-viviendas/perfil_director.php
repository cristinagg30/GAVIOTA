<?php
/* Este script gestiona la actualización de los datos personales y
la contraseña del director (administador) logueado*/
ob_start(); 
session_start();
require '../bd.php'; 
require 'general_director.php'; 

$actualizado = "";
$errores = [
    'telefono' => '',
    'fechanacimiento' => '',
    'email' => '',
    'clave_nueva' => ''
];

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header("Location: login.php");
    exit();
}

$conexion = conectar_bd();
if (!$conexion) {
    die("Error en la conexión a la base de datos.");
}

$id_director = $_SESSION['user_id'];

function obtenerInfoDirector($conexion, $id_director) {
    $query = "SELECT nombre_director, fecha_nacimiento, telefono, email, clave FROM director WHERE id_director = :id_director";
    try {
        $stmt = $conexion->prepare($query);
        $stmt->bindParam(':id_director', $id_director);
        $stmt->execute();
        return $stmt->fetch();
    } catch (PDOException $e) {
        echo "Error en la consulta: " . $e->getMessage();
        return null;
    }
}

$director_info = obtenerInfoDirector($conexion, $id_director);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['actualizar_datos'])) {
        $nombre_director = $_POST['nombre-director'];
        $fecha_nacimiento = $_POST['fechanacimiento'];
        $telefono = $_POST['telefono'];
        $email = $_POST['email'];

        if (!preg_match('/^\d{9}$/', $telefono)) {
            $errores['telefono'] = 'El número de teléfono debe contener exactamente 9 dígitos.';
        }

        $fecha_formato = DateTime::createFromFormat('Y-m-d', $fecha_nacimiento);
        if (!$fecha_formato || $fecha_formato->format('Y-m-d') !== $fecha_nacimiento) {
            $errores['fechanacimiento'] = 'La fecha de nacimiento debe tener el formato YYYY-MM-DD.';
        }

        if (!preg_match('/^[a-zA-Z0-9._%+-]+@(gmail\.com|hotmail\.com)$/', $email)) {
            $errores['email'] = 'El correo debe ser de Gmail o Hotmail.';
        }

        if (empty(array_filter($errores))) {
            $query = "UPDATE director SET nombre_director = :nombre_director, fecha_nacimiento = :fecha_nacimiento, telefono = :telefono, email = :email WHERE id_director = :id_director";
            try {
                $stmt = $conexion->prepare($query);
                $stmt->bindParam(':nombre_director', $nombre_director);
                $stmt->bindParam(':fecha_nacimiento', $fecha_nacimiento);
                $stmt->bindParam(':telefono', $telefono);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':id_director', $id_director);
                $stmt->execute();

                $director_info = obtenerInfoDirector($conexion, $id_director);
                $_SESSION['nombre'] = $nombre_director;
                ob_start();
                require 'general_director.php';
                ob_end_flush();
                $actualizado = "Datos personales actualizados con éxito.";
            } catch (PDOException $e) {
                echo "Error al actualizar los datos: " . $e->getMessage();
            }
        }
    }

    if (isset($_POST['actualizar_clave'])) {
        $nueva_clave = $_POST['nueva_clave'] ?? '';
        $confirmar_nueva_clave = $_POST['confirmar_nueva_clave'] ?? '';
        $clave_actual = $_POST['clave'] ?? '';

        if ($nueva_clave !== $confirmar_nueva_clave) {
            $errores['clave_nueva'] = 'Las contraseñas no coinciden.';
        } elseif (strlen($nueva_clave) < 6) {
            $errores['clave_nueva'] = 'La contraseña debe tener al menos 6 caracteres.';
        }

        if (empty($errores['clave_nueva'])) {
            $query = "UPDATE director SET clave = :clave WHERE id_director = :id_director";
            try {
                $stmt = $conexion->prepare($query);
                $stmt->bindParam(':clave', $nueva_clave);
                $stmt->bindParam(':id_director', $id_director);
                $stmt->execute();

                $director_info['clave'] = $nueva_clave;
                $mensaje_clave = 'Contraseña actualizada con éxito';

            } catch (PDOException $e) {
                echo "Error al actualizar la contraseña: " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas - Perfil Director</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/perfil_director.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
<main>
    <div class="form-section">
        <h3 class="title-h3">Bienvenido, <?php echo htmlspecialchars($director_info['nombre_director']); ?></h3>
        
                <?php if (!empty($actualizado)): ?>
                    <div class="mensaje-exito">
                        <h4><i class="bi bi-check2-circle"></i> <?php echo $actualizado; ?></h4>
                    </div>
                <?php endif; ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="form-grid">
            <div class="form-group">
                <label for="nombre-director">Nombre del Director:</label>
                <input type="text" id="nombre-director" name="nombre-director" value="<?php echo htmlspecialchars($director_info['nombre_director']); ?>" required >
            </div>

            <div class="form-group">
                <label for="fechanacimiento">Fecha nacimiento (YYYY-MM-DD):</label>
                <input type="text" id="fechanacimiento" name="fechanacimiento" value="<?php echo htmlspecialchars($director_info['fecha_nacimiento']); ?>" required >
                <?php if ($errores['fechanacimiento']): ?>
                    <div class="alert alert-danger" role="alert">
                        <p><?php echo $errores['fechanacimiento']; ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($director_info['telefono']); ?>" required>
                <?php if ($errores['telefono']): ?>
                            <div class="mensaje-error">
                                <p><i class="bi bi-exclamation-circle" ></i><?php echo $errores['telefono']; ?></p>
                            </div>
                        <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($director_info['email']); ?>" required>
                <?php if ($errores['email']): ?>
                    <div class="mensaje-error" role="alert">
                        <p><i class="bi bi-exclamation-circle" ></i><?php echo $errores['email']; ?></p>
                    </div>
                <?php endif; ?>
            </div>

            

            <div class="box-button">
                
            <button type="submit" class="boton" name="actualizar_datos">Actualizar datos</button>
            </div>
        </form>
        <?php if (!empty($mensaje_clave)): ?>
                <div class="mensaje-exito">
                <h4><i class="bi bi-check2-circle"></i> <?php echo $mensaje_clave; ?></h4>
                </div>
            <?php endif; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="form-grid">
        <div class="form-group">
        <label for="clave">Contraseña actual:</label>
        <div class="input-group mb-3">
        <input type="password" id="clave" name="clave" class="form-control" value="<?php echo htmlspecialchars($director_info['clave']); ?>" required readonly>
            <div class="input-group-append">
                <span class="eye-icon toggle-password" data-target="clave"><i class="fas fa-eye-slash"></i> </span>
            </div>
        </div>
    </div>

    
    <div class="form-group">
        <label for="nueva_clave">Nueva Contraseña:</label>
        <div class="input-group mb-3">
            <input type="password" id="nueva_clave" name="nueva_clave" class="form-control" placeholder="Ingrese la nueva contraseña" required>
            <div class="input-group-append">
                <span class="eye-icon toggle-password" data-target="nueva_clave">
                    <i class="fas fa-eye-slash"></i>
                </span>
            </div>
        </div>
        
        <label for="confirmar_nueva_clave">Confirmar nueva contraseña:</label>
        <div class="input-group mb-3">
            <input type="password" id="confirmar_nueva_clave" name="confirmar_nueva_clave" class="form-control" placeholder="Confirme la nueva contraseña" required>
            <div class="input-group-append">
                <span class="eye-icon toggle-password" data-target="confirmar_nueva_clave">
                    <i class="fas fa-eye-slash"></i>
                </span>
            </div>
        </div>
        <?php if ($errores['clave_nueva']): ?>
            <div class="mensaje-error" role="alert">
            <p><i class="bi bi-exclamation-circle"></i><?php echo $errores['clave_nueva']; ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="box-button">
        
        <button type="submit" class="boton" name="actualizar_clave">Actualizar contraseña</button>
    </div>
    </form>
    </div>
    </div>
    <script>
    const botonesContraseña = document.querySelectorAll('.toggle-password');
    botonesContraseña.forEach(button => {
        button.addEventListener('click', function() {
            const idCampo = this.getAttribute('data-target');
            const campoContraseña = document.getElementById(idCampo);
            
            const tipoActual = campoContraseña.getAttribute('type') === 'password' ? 'text' : 'password';
            campoContraseña.setAttribute('type', tipoActual);
            
            const icono = this.querySelector('i');
            icono.classList.toggle('fa-eye');
            icono.classList.toggle('fa-eye-slash');
        });
    });
</script>


</body>
</html>
