<?php
/* Este script permite al director gestionar el proceso de agregar los usuarios y seleccionar a qué
vivienda pertenece, verificando si la capacidad de las viviendas permite más usuarios.*/
session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error al conectar con la base de datos.");
}
$registroExito = "";
$error_agregar = "";  

function obtenerViviendas($conn) {
    $stmt = $conn->prepare("SELECT id_vivienda, nombre_vivienda FROM vivienda");
    $stmt->execute();
    return $stmt->fetchAll();
}

function viviendaLlena($conn, $id_vivienda) {
    $num_usu_vivienda = $conn->prepare("SELECT COUNT(*) AS num_usuarios FROM usuario WHERE id_vivienda = :id_vivienda");
    $num_usu_vivienda->execute([':id_vivienda' => $id_vivienda]);
    $num_usu_actuales = $num_usu_vivienda->fetchColumn();
    
    $capacidad_vivienda = $conn->prepare("SELECT num_usuarios FROM vivienda WHERE id_vivienda = :id_vivienda");
    $capacidad_vivienda->execute([':id_vivienda' => $id_vivienda]);
    $vivienda_info = $capacidad_vivienda->fetch();

    return isset($vivienda_info['num_usuarios']) && $num_usu_actuales >= $vivienda_info['num_usuarios'];
}

function obtenerViviendasConColores($conn) {
    $viviendas = obtenerViviendas($conn);
    $viviendas_colores = [];

    foreach ($viviendas as $vivienda) {
        $id_vivienda_seleccionada = $vivienda['id_vivienda'];
        $vivienda_llena = viviendaLlena($conn, $id_vivienda_seleccionada);

        $viviendas_colores[] = [
            'id_vivienda' => $vivienda['id_vivienda'],
            'nombre_vivienda' => $vivienda['nombre_vivienda'],
            'color' => $vivienda_llena ? 'background-color: #f8d7da;' : 'background-color: #d4edda;', // Rojo o verde
            'llena' => $vivienda_llena
        ];
    }

    return $viviendas_colores;
}

function agregarUsuario($conn, $id_vivienda, $datos_usuario) {
    $usu_insert = $conn->prepare("INSERT INTO usuario (id_vivienda, nombre_usuario, fecha_nacimiento, telefono, email, situacion_personal) 
                                VALUES (:id_vivienda, :nombre_usuario, :fecha_nacimiento, :telefono, :email, :situacion_personal)");
    $usu_insert->execute([
        ':id_vivienda' => $id_vivienda,
        ':nombre_usuario' => $datos_usuario['nombre_usuario'],
        ':fecha_nacimiento' => $datos_usuario['fecha_nacimiento'],
        ':telefono' => $datos_usuario['telefono'],
        ':email' => $datos_usuario['email'],
        ':situacion_personal' => $datos_usuario['situacion_personal']
    ]);

    $id_usuario = $conn->lastInsertId();

    $responsables_usuario = $conn->prepare("SELECT id_responsable FROM responsable WHERE id_vivienda = :id_vivienda");
    $responsables_usuario->execute([':id_vivienda' => $id_vivienda]);
    $responsables_vivienda = $responsables_usuario->fetchAll();

    foreach ($responsables_vivienda as $responsable) {
        $responsable_insert = $conn->prepare("INSERT INTO responsable_usuario (id_usuario, id_responsable) 
                                            VALUES (:id_usuario, :id_responsable)");
        $responsable_insert->execute([
            ':id_usuario' => $id_usuario,
            ':id_responsable' => $responsable['id_responsable']
        ]);
    }
}

$viviendas_colores = obtenerViviendasConColores($conn);
$vivienda_llena = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_vivienda = intval($_POST['id_vivienda']);

    if (viviendaLlena($conn, $id_vivienda)) {
        $vivienda_llena = true;
        $error_agregar = "No puedes agregar más usuarios a esta vivienda, el límite de usuarios ha sido alcanzado.";
    } else {
        $datos_usuario = [
            'nombre_usuario' => $_POST['nombre_usuario'],
            'fecha_nacimiento' => $_POST['fecha_nacimiento'],
            'telefono' => $_POST['telefono'],
            'email' => $_POST['email'],
            'situacion_personal' => $_POST['situacion_personal']
        ];

        if (empty($id_vivienda) || empty($datos_usuario['nombre_usuario']) || empty($datos_usuario['fecha_nacimiento']) || empty($datos_usuario['email'])) {
            $error_agregar = "Por favor, complete todos los campos obligatorios.";
        } else {
            $usu_email = $conn->prepare("SELECT COUNT(*) FROM usuario WHERE email = :email");
            $usu_email->execute([':email' => $datos_usuario['email']]);
            $email_existente = $usu_email->fetchColumn();

            if ($email_existente > 0) {
                $error_agregar = "El correo electrónico ya está en uso. Por favor, ingrese otro.";
            } else {
                try {
                    agregarUsuario($conn, $id_vivienda, $datos_usuario);
                    $registroExito = "Usuario agregado con éxito.";
                } catch (Exception $e) {
                    $error_agregar = "Error al agregar usuario: " . $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Usuario</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/add_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
    <div class="container-fluid">
        <main>
            <div class="form-section">
                <h3 class="title-h3">Agregar Usuario</h3>

                <?php if (!empty($registroExito)): ?>
                    <div class="alert alert-success">
                        <h4><i class="bi bi-check2-circle"></i> <?php echo $registroExito; ?></h4>
                    </div>
                <?php endif; ?>

                <?php if (!empty($error_agregar)): ?>
                    <div class="alert alert-danger">
                        <h4><i class="bi bi-x-circle"></i> <?php echo $error_agregar; ?></h4>
                    </div>
                <?php endif; ?>

                <form method="POST" action="add_usuarios_d.php" class="form-grid">
                    <div class="form-group">
                        <label for="id_vivienda">Seleccionar Vivienda:</label>
                        <select name="id_vivienda" id="id_vivienda" required>
                            <option value="" disabled selected>Seleccionar vivienda</option>
                            <?php foreach ($viviendas_colores as $vivienda): ?>
                                <option value="<?php echo $vivienda['id_vivienda']; ?>" style="<?php echo $vivienda['color']; ?>">
                                    <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="nombre_usuario">Nombre del Usuario:</label>
                        <input type="text" id="nombre_usuario" name="nombre_usuario" required>
                    </div>
                    <div class="form-group">
                        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
                    </div>
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="situacion_personal">Situación Personal:</label>
                        <textarea id="situacion_personal" name="situacion_personal"></textarea>
                    </div>
                    <button type="submit" class="boton">Agregar Usuario</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
