<?php
/* Este script permite al director gestionar la asignación de responsables a las viviendas. 
Obtiene las viviendas disponibles desde la base de datos. 
Permite agregar un nuevo responsable y almacenarlo en la base de datos */
session_start();

require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error al conectar con la base de datos.");
}

$error_agregar = '';
$registroExito = '';

function obtenerViviendas($conn) {
    try {
        $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener las viviendas: " . $e->getMessage());
    }
}

function agregarResponsable($conn, $datos) {
    $primer_nombre = strtok($datos['nombre_responsable'], ' ');
    $primer_nombre = strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $primer_nombre));
    $primer_nombre = preg_replace('/[^a-z]/', '', $primer_nombre);
    $clave = $primer_nombre . '1234';

    $sql = "INSERT INTO responsable (nombre_responsable, id_vivienda, fecha_nacimiento, titulo_academico, telefono, email, clave) 
            VALUES (:nombre_responsable, :id_vivienda, :fecha_nacimiento, :titulo_academico, :telefono, :email, :clave)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':nombre_responsable' => $datos['nombre_responsable'],
        ':id_vivienda' => $datos['id_vivienda'],
        ':fecha_nacimiento' => $datos['fecha_nacimiento'],
        ':titulo_academico' => $datos['titulo_academico'],
        ':telefono' => $datos['telefono'],
        ':email' => $datos['email'],
        ':clave' => $clave,
    ]);
    return $clave;
}

try {
    $viviendas = obtenerViviendas($conn);
} catch (Exception $e) {
    $error_agregar = $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nombre_responsable'])) {
    if (empty($_POST['id_vivienda'])) {
        $error_agregar = "Debe seleccionar una vivienda.";
    } else {
        $datos_responsable = [
            'nombre_responsable' => $_POST['nombre_responsable'],
            'id_vivienda' => $_POST['id_vivienda'],
            'fecha_nacimiento' => $_POST['fecha_nacimiento'],
            'titulo_academico' => $_POST['titulo_academico'],
            'telefono' => $_POST['telefono'],
            'email' => $_POST['email'],
        ];

        try {
            $clave = agregarResponsable($conn, $datos_responsable);
            $registroExito = "Responsable agregado con éxito. La clave predeterminada es: " . htmlspecialchars($clave);
        } catch (Exception $e) {
            $error_agregar = "Error al agregar responsable: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Responsable</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/add_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
    <div class="container-fluid">
        <main>
            <div class="form-section">
                <h3 class="title-h3">Agregar Responsable</h3>

                    <?php if (!empty($registroExito)): ?>
                        <div class="alert alert-success">
                            <h4><i class="bi bi-check2-circle"></i> <?php echo $registroExito; ?></h4>
                        </div>
                    <?php endif; ?>
                <form method="POST" action="add_responsable_d.php" class="form-grid">
                    <div class="form-group">
                        <label for="nombre_responsable">Nombre del Responsable:</label>
                        <input type="text" id="nombre_responsable" name="nombre_responsable" required>
                    </div>
                    <div class="form-group">
                        <label for="id_vivienda">Seleccionar Vivienda:</label>
                            <select name="id_vivienda" id="id_vivienda" required>
                            <option value="" disabled selected>Seleccionar vivienda</option>
                                <?php foreach ($viviendas as $vivienda): ?>
                                    <option value="<?php echo $vivienda['id_vivienda']; ?>">
                                        <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                    </div>

                    <div class="form-group">
                        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" required>
                    </div>

                    <div class="form-group">
                        <label for="titulo_academico">Título Académico:</label>
                        <input type="text" id="titulo_academico" name="titulo_academico">
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono">
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <button type="submit" class="boton">Agregar Responsable</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>
