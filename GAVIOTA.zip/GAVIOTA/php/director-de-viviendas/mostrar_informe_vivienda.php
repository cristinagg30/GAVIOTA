<?php 
/* Este script nos muestra las informes relacionadas con las viviendas registradas.
Seleccionamos una de las vivienda y nos muestra las informes según la acción solicitada.*/

session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

$id_director = $_SESSION['user_id'];


function obtenerinformesPorVivienda($conn, $id_vivienda) {
    try {
        $stmt = $conn->prepare("SELECT * FROM informe_vivienda WHERE id_vivienda = :id_vivienda");
        $stmt->execute([':id_vivienda' => $id_vivienda]);
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return []; 
    }
}

function obtenerViviendas($conn) {
    try {
        $stmt = $conn->prepare("SELECT id_vivienda, nombre_vivienda FROM vivienda");
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return []; 
    }
}

$informes = [];
$viviendas = obtenerViviendas($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'view_incidents') {
    $id_vivienda = $_POST['id_vivienda'] ?? null;

    if ($id_vivienda) {
        $informes = obtenerinformesPorVivienda($conn, $id_vivienda);
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de informes</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/mostrar_incid_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>

<div class="container-fluid">
    <main>
        <div class="form-section">
        
        <h3 class="title-h3">Ver informes de Vivienda</h3>
            <form action="mostrar_informe_vivienda.php" method="post">
            <div class="form-group">
                <input type="hidden" name="action" value="view_incidents">

                <label>Selecciona la Vivienda:</label>
                <select name="id_vivienda" required>
                    <option value="">Selecciona una Vivienda</option>
                    <?php foreach ($viviendas as $vivienda) { ?>
                        <option value="<?php echo $vivienda['id_vivienda']; ?>"><?php echo $vivienda['nombre_vivienda']; ?></option>
                    <?php } ?>
                </select><br>

                <button type="submit" class="boton">Ver informes</button>
            </div>
                    </form>

            <hr>
            <?php if (!empty($informes)): ?>
                <h5 class="card-header titulo-h5">informes de la Vivienda <?php echo $vivienda['nombre_vivienda']; ?></h5>
                <div class="cards-container-scroll">
                <table>
                    <thead>
                        <tr>
                            <th class="card-text">Título</th>
                            <th class="card-text">Descripción</th>
                            <th class="card-text">Fecha</th>
                            <th class="card-text">Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($informes as $informe): ?>
                            <tr>
                                <td ><?php echo htmlspecialchars($informe['titulo']); ?></td>
                                <td class="descripcion"><?php echo htmlspecialchars($informe['descripcion']); ?></td>
                                <td class="fecha"><?php echo htmlspecialchars($informe['fecha_informe']); ?></td>
                                <td class="estado <?php echo ($informe['estado'] === 'pendiente') ? 'estado-pendiente' : ($informe['estado'] === 'resuelta' ? 'estado-resuelta' : ''); ?>">
                                    <?php echo htmlspecialchars($informe['estado']); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($informes)): ?>
                <p>No hay informes registrados para esta vivienda.</p>
            <?php endif; ?>
        </div>
        </div>
        </div>
    </main>
</div>
</body>
</html>
