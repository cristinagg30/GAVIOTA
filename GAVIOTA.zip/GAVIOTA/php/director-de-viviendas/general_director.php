<?php
/* Parte común del rol de director */
require_once '../bd.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd(); 

$id_responsable = $_SESSION['user_id'];

$query = "SELECT COUNT(*) FROM mensajes WHERE (id_destinatario_responsable = :id_responsable OR id_destinatario_director = :id_responsable) AND leido = 0";
$stmt = $conn->prepare($query);
$stmt->execute([':id_responsable' => $id_responsable]);

$total_no_leidos = $stmt->fetchColumn();


ob_start(); 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="icon" href="../../img/gaviota.png" type="image/x-icon">
    <link rel="stylesheet" href="../../css/director-de-vivienda/general_director.css">
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">    
</head>
<body>
    <!--------------------         CABECERA        ----------------------->
    <header class="header">
        <div class="div-logo">
        <p class="siglas">GAVIOTA</p>
            <a href="home_director.php"><img src="../../img/gaviota.png" alt="Logo de Gestión de Viviendas"></a>
            <h3 class="titulo"></h3>
            
        </div>
        <div class="notificaciones">
                <?php if ($total_no_leidos > 0): ?>
                    <div class="box-mensaje">
                        <a href="../director-de-viviendas/mensajes_d.php"> <?php echo $total_no_leidos; ?> Mensajes Pendientes</a>
                    </div>
                <?php endif; ?>
            </div> 
            <nav class="nav-header">
                    <a href="perfil_director.php" class="link-respon"><i class="bi bi-person-circle icono"></i>
                        <?php 
                            if (isset($_SESSION['nombre'])) {
                                echo "" . $_SESSION['nombre'] . "";
                            }
                        ?>
                    </a>
                    <a href="../logout.php" id="logout-link" ><i class="bi bi-box-arrow-left"></i> Cerrar Sesión</a>
            </nav>
    </header>

    <!--------------------         CUERPO PRINCIPAL         ----------------------->
    <main></main>

    <!--------------------         PIE DE PAGINA         ----------------------->
    <footer class="footer">
        <p>&copy; 2025 Gestión Asistencial Viviendas Online Tuteladas</p>
    </footer>
    <script src="../../bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    const iconoMenu = document.getElementById('icono-menu');
    const logoutLink = document.getElementById('logout-link');

    iconoMenu.addEventListener('click', function() {
        if (logoutLink.style.display === 'none' || logoutLink.style.display === '') {
            logoutLink.style.display = 'block';
            iconoMenu.classList.remove('bi-caret-down-fill');
            iconoMenu.classList.add('bi-caret-up-fill');
        } else {
            logoutLink.style.display = 'none';
            iconoMenu.classList.remove('bi-caret-up-fill');
            iconoMenu.classList.add('bi-caret-down-fill');
        }
    });
</script>
</body>
</html>


