<?php
/* Este script permite al director consultar la lista de responsables asociados a las viviendas 
registradas . Además, ofrece la opción de filtrar los responsables seleccionando 
una vivienda específica para mostrar únicamente los responsables relacionados con ella. */

session_start();

require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error al conectar con la base de datos.");
}

function obtenerViviendas($conn){
    $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}


function obtenerResponsables($conn, $id_vivienda = ''){
    $sql = "SELECT r.id_responsable, r.nombre_responsable, r.fecha_nacimiento, r.titulo_academico, r.telefono, 
            r.email, v.nombre_vivienda 
            FROM responsable r
            LEFT JOIN vivienda v ON r.id_vivienda = v.id_vivienda";
    
    if (!empty($id_vivienda)) {
        $sql .= " WHERE r.id_vivienda = :id_vivienda";
    }

    $stmt = $conn->prepare($sql);
    if (!empty($id_vivienda)) {
        $stmt->bindParam(':id_vivienda', $id_vivienda);
    }
    $stmt->execute();
    return $stmt->fetchAll();
}


$viviendas = obtenerViviendas($conn);

$id_vivienda_filtrado = isset($_GET['id_vivienda']) ? $_GET['id_vivienda'] : '';
$responsables = obtenerResponsables($conn, $id_vivienda_filtrado);


$conn = null;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Responsables</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/read_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>

<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Información de los Responsables</h3>

            <form method="GET" action="">
            <div class="form-group">
                <label for="id_vivienda">Seleccionar Vivienda:</label>
                <select name="id_vivienda" id="id_vivienda">
                    <option value="">Todos los responsables</option>
                    <?php foreach ($viviendas as $vivienda): ?>
                        <option value="<?php echo $vivienda['id_vivienda']; ?>" 
                                <?php echo (isset($_GET['id_vivienda']) && $_GET['id_vivienda'] == $vivienda['id_vivienda']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="button-filtrar">Filtrar</button>
            </div>
                    </form>

            <hr>
            <div class="cards-container-scroll">
            <?php if (!empty($responsables)): ?>
                <?php foreach ($responsables as $responsable): ?>
                    <div class="card">
                        <h5 class="card-header titulo-h5">Nombre del Responsable: <?php echo htmlspecialchars($responsable['nombre_responsable']); ?></h5>
                        <div class="card-body">
                            <p><b class="card-text">Fecha de Nacimiento:</b> <?php echo htmlspecialchars($responsable['fecha_nacimiento']); ?></p>
                            <p><b class="card-text">Título Académico:</b> <?php echo htmlspecialchars($responsable['titulo_academico']); ?></p>
                            <p><b class="card-text">Teléfono:</b> <?php echo htmlspecialchars($responsable['telefono']); ?></p>
                            <p><b class="card-text">Email:</b> <?php echo htmlspecialchars($responsable['email']); ?></p>
                            <p><b class="card-text">Vivienda asociada:</b> <?php echo htmlspecialchars($responsable['nombre_vivienda']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No se encontraron responsables.</p>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
