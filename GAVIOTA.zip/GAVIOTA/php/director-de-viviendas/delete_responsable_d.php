<?php
/* Este script permite al director eliminar responsables. */
session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

function obtenerResponsables($conn) {
    try {
        $stmt = $conn->query("SELECT id_responsable, nombre_responsable FROM responsable");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

function eliminarResponsable($conn, $responsable_id) {
    try {
        if (empty($responsable_id)) {
            throw new Exception("No se ha seleccionado un responsable.");
        }
        
        $stmt = $conn->prepare("DELETE FROM responsable WHERE id_responsable = :id_responsable");
        $stmt->execute([':id_responsable' => $responsable_id]);

        if ($stmt->rowCount() > 0) {
            return "El responsable se eliminó exitosamente.";
        } else {
            throw new Exception("No se pudo eliminar el responsable, por favor intente nuevamente.");
        }
    } catch (Exception $e) {
        return "Error al eliminar el responsable: " . $e->getMessage();
    }
}

$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['responsable_id'])) {
    $responsable_id = $_POST['responsable_id'];
    $resultado = eliminarResponsable($conn, $responsable_id);

    if (strpos($resultado, 'Error') === 0) {
        $error_message = $resultado;
    } else {
        $success_message = $resultado;
    }
}

$responsables = obtenerResponsables($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Responsable</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/delete_d.css">
</head>
<body>
<?php include 'nav_director.php'; ?>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Eliminar Responsable</h3>
            
            <form id="eliminarForm" action="delete_responsable_d.php" method="post" style="display: none;">
                <input type="hidden" name="responsable_id" id="responsable_id">
            </form>

            <form onsubmit="event.preventDefault(); mostrarModal();">
                <div class="form-selecc">
                    <label for="responsable_select">Seleccionar responsable para eliminar:</label>
                    <select id="responsable_select" name="responsable_id" required>
                        <option value="">Selecciona responsable</option>
                        <?php foreach ($responsables as $responsable): ?>
                            <option value="<?= $responsable['id_responsable'] ?>"><?= $responsable['nombre_responsable'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Eliminar Responsable</button>
                </div>
            </form>

            <div id="overlay" class="overlay"></div>
            <div id="confirmModal" class="modal">
                <div class="modal-content">
                    <h3>¿Estás seguro de que deseas eliminar este responsable?</h3>
                    <p>Esta acción no se puede deshacer.</p>
                    <button class="cancel-btn" onclick="cerrarModal()">Cancelar</button>
                    <button class="confirm-btn" onclick="confirmarEliminacion()">Eliminar</button>
                </div>
            </div>

            <?php if ($error_message): ?>
                <div class="alert-error alert-danger">
                    <h4><i class="bi bi-x-circle"></i> <?php echo $error_message; ?></h4>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert-correcto alert-success">
                    <h4><i class="bi bi-check2-circle"></i> <?php echo $success_message; ?></h4>
                </div>
            <?php endif; ?>

        </div>
    </main>
</div>
<script>
    function mostrarModal() {
        var responsableSeleccionado = document.getElementById('responsable_select').value;
        
        if (responsableSeleccionado !== "") {
            document.getElementById('responsable_id').value = responsableSeleccionado; 
            document.getElementById('confirmModal').style.display = 'flex';
            document.getElementById('overlay').style.display = 'block';
        } else {
            alert('Por favor, selecciona un responsable.');
        }
    }

    function cerrarModal() {
        document.getElementById('confirmModal').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }

    function confirmarEliminacion() {
        document.getElementById('eliminarForm').submit();
    }
</script>
</body>
</html>
