<?php
/* Este script permite al director eliminar usuarios. */
session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

function obtenerUsuarios($conn) {
    try {
        $stmt = $conn->query("SELECT id_usuario, nombre_usuario FROM usuario");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        return [];
    }
}

function eliminarUsuario($conn, $usuario_id) {
    try {
        if (empty($usuario_id)) {
            throw new Exception("No se ha seleccionado un usuario.");
        }

        $stmt = $conn->prepare("DELETE FROM usuario WHERE id_usuario = :id_usuario");
        $stmt->execute([':id_usuario' => $usuario_id]);

        if ($stmt->rowCount() > 0) {
            return "El usuario se eliminó exitosamente.";
        } else {
            throw new Exception("No se pudo eliminar el usuario, por favor intente nuevamente.");
        }
    } catch (Exception $e) {
        return "Error al eliminar el usuario: " . $e->getMessage();
    }
}

$error_message = "";
$success_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usuario_id'])) {
    $usuario_id = $_POST['usuario_id'];
    $resultado = eliminarUsuario($conn, $usuario_id);

    if (strpos($resultado, 'Error') === 0) {
        $error_message = $resultado;
    } else {
        $success_message = $resultado;
    }
}

$usuarios = obtenerUsuarios($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Usuario</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/delete_d.css">
</head>
<body>
<?php include 'nav_director.php'; ?>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Eliminar Usuario</h3>
            
            <form id="eliminarForm" action="delete_usuarios_d.php" method="post" style="display: none;">
                <input type="hidden" name="usuario_id" id="usuario_id">
            </form>

            <form onsubmit="event.preventDefault(); mostrarModal();">
                <div class="form-selecc">
                    <label for="usuario_select">Seleccionar usuario para eliminar:</label>
                    <select id="usuario_select" name="usuario_id" required>
                        <option value="">Seleccionar usuario</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?= $usuario['id_usuario'] ?>"><?= $usuario['nombre_usuario'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Eliminar Usuario</button>
                </div>
            </form>

            <div id="overlay" class="overlay"></div>
            <div id="confirmModal" class="modal">
                <div class="modal-content">
                    <h3>¿Estás seguro de que deseas eliminar este usuario?</h3>
                    <p>Esta acción no se puede deshacer.</p>
                    <button class="cancel-btn" onclick="cerrarModal()">Cancelar</button>
                    <button class="confirm-btn" onclick="confirmarEliminacion()">Eliminar</button>
                </div>
            </div>

            
            <?php if ($error_message): ?>
                <div class="alert-error alert-danger">
                    <h4><i class="bi bi-x-circle"></i> <?php echo $error_message; ?></h4>
                </div>
            <?php endif; ?>

            <?php if ($success_message): ?>
                <div class="alert-correcto alert-success">
                    <h4><i class="bi bi-check2-circle"></i> <?php echo $success_message; ?></h4>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
<script>
    function mostrarModal() {
        const usuarioSelect = document.getElementById('usuario_select');
        const usuarioId = document.getElementById('usuario_id');
        usuarioId.value = usuarioSelect.value;

        if (usuarioId.value) {
            document.getElementById('confirmModal').style.display = 'flex';
            document.getElementById('overlay').style.display = 'block';
        } else {
            alert("Por favor, selecciona un usuario.");
        }
    }

    function cerrarModal() {
        document.getElementById('confirmModal').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }

    function confirmarEliminacion() {
        document.getElementById('eliminarForm').submit();
    }
</script>
</body>
</html>
