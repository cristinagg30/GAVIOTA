<?php
/* Este script permite al director consultar la lista de Viviendas registradas.
Además, ofrece la opción de filtrar las viviendas. */
session_start();

require '../bd.php';
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error en la conexión a la base de datos.");
}


function obtenerViviendas($conn, $id_vivienda_filtrado = ''){
    $sql = "SELECT v.*, u.nombre_usuario, u.email AS usuario_email, r.nombre_responsable, r.email AS responsable_email
            FROM vivienda v
            LEFT JOIN usuario u ON v.id_vivienda = u.id_vivienda
            LEFT JOIN responsable r ON v.id_vivienda = r.id_vivienda";

    if ($id_vivienda_filtrado != '') {
        $sql .= " WHERE v.id_vivienda = :id_vivienda";
    }

    $stmt = $conn->prepare($sql);

    if ($id_vivienda_filtrado != '') {
        $stmt->bindParam(':id_vivienda', $id_vivienda_filtrado);
    }

    $stmt->execute();
    return $stmt->fetchAll();
}


function obtenerViviendasFiltro($conn){
    $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

$id_vivienda_filtrado = isset($_GET['id_vivienda']) ? $_GET['id_vivienda'] : '';

$viviendas = obtenerViviendas($conn, $id_vivienda_filtrado);
$viviendas_select = obtenerViviendasFiltro($conn);

$viviendasAgrupadas = [];
if (!empty($viviendas)) {
    foreach ($viviendas as $vivienda) {
        $id_vivienda = $vivienda['id_vivienda'];
        if (!isset($viviendasAgrupadas[$id_vivienda])) {
            $viviendasAgrupadas[$id_vivienda] = [
                'info' => $vivienda,
                'usuarios' => [],
                'responsables' => []
            ];
        }

        if (!empty($vivienda['nombre_usuario'])) {
            $viviendasAgrupadas[$id_vivienda]['usuarios'][$vivienda['usuario_email']] = [
                'nombre' => $vivienda['nombre_usuario'],
                'email' => $vivienda['usuario_email']
            ];
        }

        if (!empty($vivienda['nombre_responsable'])) {
            $viviendasAgrupadas[$id_vivienda]['responsables'][$vivienda['responsable_email']] = [
                'nombre' => $vivienda['nombre_responsable'],
                'email' => $vivienda['responsable_email']
            ];
        }
    }
}


$conn = null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/read_d.css">
</head>
<body>
<?php include 'nav_director.php'; ?>

<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Información de Viviendas</h3>

            <form method="GET" action="">
                <div class="form-group">
                    <label for="id_vivienda" class="texto">Seleccionar Vivienda:</label>
                    <select name="id_vivienda" id="id_vivienda">
                        <option value="">Todas las viviendas</option>
                        <?php foreach ($viviendas_select as $vivienda): ?>
                            <option value="<?php echo htmlspecialchars($vivienda['id_vivienda']); ?>" 
                                <?php echo ($id_vivienda_filtrado == $vivienda['id_vivienda']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="button-filtrar">Filtrar</button>
                </div>
            </form>

            <?php if (!empty($viviendasAgrupadas)): ?>
                <div class="cards-container-scroll">
                    <?php foreach ($viviendasAgrupadas as $viviendaData): ?>
                        <?php $vivienda = $viviendaData['info']; ?>
                        <div class="card">
                            <h5 class="card-header titulo-h5"><b>Nombre:</b> <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?></h5>
                            <div class="card-body">
                                <h5 class="card-text">Dirección:</h5>
                                <p>
                                    C/<?php echo htmlspecialchars($vivienda['calle']) . ' ' . 
                                            htmlspecialchars($vivienda['numero']) . ', ' . 
                                            htmlspecialchars($vivienda['piso']) . ', ' . 
                                            htmlspecialchars($vivienda['ciudad']) . ', ' . 
                                            htmlspecialchars($vivienda['provincia']) . ', ' . 
                                            htmlspecialchars($vivienda['codigo_postal']); ?>
                                </p>
                                <h5 class="card-text">Información:</h5>
                                <p><?php echo htmlspecialchars($vivienda['informacion']); ?></p>

                                <h5 class="card-text">Usuarios:</h5>
                                <?php if (!empty($viviendaData['usuarios'])): ?>
                                    <ul>
                                        <?php foreach ($viviendaData['usuarios'] as $usuario): ?>
                                            <li><b>Nombre:</b> <?php echo htmlspecialchars($usuario['nombre']); ?> | <b>Email:</b> <?php echo htmlspecialchars($usuario['email']); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p>No hay usuarios asociados.</p>
                                <?php endif; ?>

                                <h5 class="card-text">Responsables:</h5>
                                <?php if (!empty($viviendaData['responsables'])): ?>
                                    <ul>
                                        <?php foreach ($viviendaData['responsables'] as $responsable): ?>
                                            <li><b>Nombre:</b> <?php echo htmlspecialchars($responsable['nombre']); ?> | <b>Email:</b> <?php echo htmlspecialchars($responsable['email']); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p>No hay responsables asociados.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>No se encontraron viviendas.</p>
            <?php endif; ?>
        </div>
    </main>
</div>

</body>
</html>
