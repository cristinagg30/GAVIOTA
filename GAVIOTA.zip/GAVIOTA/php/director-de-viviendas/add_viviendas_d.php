<?php
/* Este script permite al director gestionar el proceso de agregar viviendas siempre que 
el nombre de la vivienda no esté ya en la base de datos.*/

session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error al conectar con la base de datos.");
}

$error_message = "";
$success_agregar = "";

function agregarVivienda($conn, $datos){
    try {
        $conn->beginTransaction();

        $check_stmt = $conn->prepare("SELECT COUNT(*) FROM vivienda WHERE nombre_vivienda = :nombre_vivienda");
        $check_stmt->execute([':nombre_vivienda' => $datos['nombre_vivienda']]);
        $count = $check_stmt->fetchColumn();

        if ($count > 0) {
            throw new Exception("El nombre de la vivienda ya está registrado.");
        }

        $stmt = $conn->prepare(" INSERT INTO vivienda (nombre_vivienda, calle, numero, piso, ciudad, provincia, codigo_postal, num_usuarios, informacion)
                                VALUES (:nombre_vivienda, :calle, :numero, :piso, :ciudad, :provincia, :codigo_postal, :num_usuarios, :informacion)");
        $stmt->execute([ 
            ':nombre_vivienda' => $datos['nombre_vivienda'],
            ':calle' => $datos['calle'],
            ':numero' => $datos['numero'],
            ':piso' => $datos['piso'],
            ':ciudad' => $datos['ciudad'],
            ':provincia' => $datos['provincia'],
            ':codigo_postal' => $datos['codigo_postal'],
            ':num_usuarios' => $datos['num_usuarios'],
            ':informacion' => $datos['informacion'],
        ]);

        $conn->commit();
        return "Vivienda agregada con éxito.";

    } catch (Exception $e) {
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        return $e->getMessage();  
    }
}

$datos_vivienda = [
    'nombre_vivienda' => '',
    'calle' => '',
    'numero' => '',
    'piso' => '',
    'ciudad' => '',
    'provincia' => '',
    'codigo_postal' => '',
    'num_usuarios' => '',
    'informacion' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $datos_vivienda = [
        'nombre_vivienda' => $_POST['nombre_vivienda'] ?? '',
        'calle' => $_POST['calle'] ?? '',
        'numero' => $_POST['numero'] ?? '',
        'piso' => $_POST['piso'] ?? '',
        'ciudad' => $_POST['ciudad'] ?? '',
        'provincia' => $_POST['provincia'] ?? '',
        'codigo_postal' => $_POST['codigo_postal'] ?? '',
        'num_usuarios' => $_POST['num_usuarios'] ?? '',
        'informacion' => $_POST['informacion'] ?? '',
    ];

    $resultado = agregarVivienda($conn, $datos_vivienda);

    if ($resultado === "Vivienda agregada con éxito.") {
        $success_agregar = $resultado;
        $datos_vivienda = [
            'nombre_vivienda' => '',
            'calle' => '',
            'numero' => '',
            'piso' => '',
            'ciudad' => '',
            'provincia' => '',
            'codigo_postal' => '',
            'num_usuarios' => '',
            'informacion' => ''
        ];
    } else {
        $error_message = $resultado;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Vivienda</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/add_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Añadir vivienda</h3>
        
            <?php if ($success_agregar): ?>
                <div class="alert alert-success">
                    <h4><i class="bi bi-check2-circle"></i> <?php echo $success_agregar; ?></h4>
                </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
                <div class="alert alert-danger">
                    <h4><i class="bi bi-x-circle"></i> <?php echo $error_message; ?></h4>
                </div>
            <?php endif; ?>

            <form method="POST" action="add_viviendas_d.php" class="form-grid">
                <div class="form-group vivienda">
                    <input type="hidden" name="action" value="add"> 
                    <label for="nombre_vivienda">Nombre de la Vivienda:</label>
                    <input type="text" id="nombre_vivienda" name="nombre_vivienda" value="<?php echo htmlspecialchars($datos_vivienda['nombre_vivienda']); ?>" required><br>
                </div>
                <div class="form-group vivienda">
                    <label for="calle">Calle:</label>
                    <input type="text" id="calle" name="calle" value="<?php echo htmlspecialchars($datos_vivienda['calle']); ?>" required><br>
                </div>
                <div class="form-group vivienda">
                    <label for="numero">Número:</label>
                    <input type="number" id="numero" name="numero" value="<?php echo htmlspecialchars($datos_vivienda['numero']); ?>" required><br>
                </div>
                <div class="form-group vivienda">
                    <label for="piso">Piso:</label>
                    <input type="text" id="piso" name="piso" value="<?php echo htmlspecialchars($datos_vivienda['piso']); ?>"><br>
                </div>

                <div class="form-group vivienda">
                    <label for="ciudad">Ciudad:</label>
                    <input type="text" id="ciudad" name="ciudad" value="<?php echo htmlspecialchars($datos_vivienda['ciudad']); ?>" required><br>
                </div>

                <div class="form-group vivienda">
                    <label for="provincia">Provincia:</label>
                    <input type="text" id="provincia" name="provincia" value="<?php echo htmlspecialchars($datos_vivienda['provincia']); ?>" required><br>
                </div>

                <div class="form-group vivienda">
                    <label for="codigo_postal">Código Postal:</label>
                    <input type="number" id="codigo_postal" name="codigo_postal" value="<?php echo htmlspecialchars($datos_vivienda['codigo_postal']); ?>" required><br>
                </div>

                <div class="form-group vivienda">
                    <label for="num_usuarios">Número de Usuarios:</label>
                    <input type="number" id="num_usuarios" name="num_usuarios" value="<?php echo htmlspecialchars($datos_vivienda['num_usuarios']); ?>" required min="1"><br>
                </div>
                <div class="form-group vivienda">
                <label for="informacion" class="label-textarea">Información Adicional:</label>
                <textarea id="informacion" name="informacion" required><?php echo htmlspecialchars($datos_vivienda['informacion']); ?></textarea><br>
                </div>
                <button type="submit" class="boton">Añadir Vivienda</button>
            </form>
        </div>
    </main>
</div>
</body>
</html>
