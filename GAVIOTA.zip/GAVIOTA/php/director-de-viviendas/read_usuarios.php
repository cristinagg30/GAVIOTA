<?php
/* Este script permite al director consultar la lista de usuarios registrados.
Además, ofrece la opción de filtrar por vivienda. */
session_start();

require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();
if (!$conn) {
    die("Error al conectar con la base de datos.");
}

function obtenerViviendas($conn) {
    $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll();
}

function obtenerUsuarios($conn, $id_vivienda = '') {
    $sql = "SELECT 
                u.id_usuario, 
                u.nombre_usuario, 
                u.email, 
                u.situacion_personal, 
                u.id_vivienda,
                v.nombre_vivienda 
            FROM usuario u
            LEFT JOIN vivienda v ON u.id_vivienda = v.id_vivienda";
    if (!empty($id_vivienda)) {
        $sql .= " WHERE u.id_vivienda = :id_vivienda";
    }
    $stmt = $conn->prepare($sql);
    if (!empty($id_vivienda)) {
        $stmt->bindParam(':id_vivienda', $id_vivienda);
    }
    $stmt->execute();
    return $stmt->fetchAll();
}

function obtenerResponsables($conn, $id_vivienda) {
    $stmt = $conn->prepare("SELECT nombre_responsable, email, telefono FROM responsable WHERE id_vivienda = :id_vivienda");
    $stmt->execute([':id_vivienda' => $id_vivienda]);
    return $stmt->fetchAll();
}

$viviendas = obtenerViviendas($conn);

$id_vivienda_filtrado = isset($_GET['id_vivienda']) ? $_GET['id_vivienda'] : '';
$usuarios = obtenerUsuarios($conn, $id_vivienda_filtrado);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Viviendas</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/read_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Información de los usuarios</h3>
            
            <form method="GET" action="">
                <div class="form-group">
                    <label for="id_vivienda">Seleccionar Vivienda:</label>
                    <select name="id_vivienda" id="id_vivienda">
                        <option value="">Todos los usuarios</option>
                        <?php foreach ($viviendas as $vivienda): ?>
                            <option value="<?php echo $vivienda['id_vivienda']; ?>" 
                                <?php echo (isset($_GET['id_vivienda']) && $_GET['id_vivienda'] == $vivienda['id_vivienda']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="button-filtrar">Filtrar</button>
                </div>
            </form>

            <div class="cards-container-scroll">
                <?php if (!empty($usuarios)): ?>
                    <?php foreach ($usuarios as $usuario): ?>
                        <div class="card">
                            <h5 class="card-header titulo-h5">Nombre de usuario: <?php echo htmlspecialchars($usuario['nombre_usuario']); ?></h5>
                            <div class="card-usuarios">
                                <p class="responsable-header">Datos usuario:</p>
                                <p class="nombre-usuario"><b class="card-text">Nombre:</b> <?php echo htmlspecialchars($usuario['nombre_usuario']); ?></p>
                                <p class="vivienda-usuario"><b class="card-text">Vivienda:</b> <?php echo htmlspecialchars($usuario['nombre_vivienda']); ?></p>
                                <p class="email-usuario"><b class="card-text">Email:</b> <?php echo htmlspecialchars($usuario['email']); ?></p>
                                <p class="responsable-header">Situación personal:</p>
                                <p class="situacion-personal"><?php echo htmlspecialchars($usuario['situacion_personal']); ?></p>
                                <p class="responsable-header">Responsable(s) asociado(s):</p>
                                <?php if (!empty($usuario['id_vivienda'])): ?>
                                    <?php 
                                        $responsables = obtenerResponsables($conn, $usuario['id_vivienda']);
                                        if (!empty($responsables)):
                                            foreach($responsables as $responsable):
                                    ?>
                                        <p class="nombre-responsable"><b class="card-text">Nombre:</b> <?php echo htmlspecialchars($responsable['nombre_responsable']); ?></p>
                                        <p class="telefono-responsable"><b class="card-text">Teléfono:</b> <?php echo htmlspecialchars($responsable['telefono']); ?></p>
                                        <p class="email-responsable"><b class="card-text">Email:</b> <?php echo htmlspecialchars($responsable['email']); ?></p>
                                    <?php 
                                            endforeach;
                                        else:
                                    ?>
                                        <p>No tiene responsable asignado.</p>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <p>No tiene responsable asignado.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No se encontraron usuarios.</p>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
</body>
</html>
