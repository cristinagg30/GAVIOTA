<?php
/* Este script permite al director gestionar la información de los usuarios. 
Se filtra por usuario para editar sus datos personales y la vivienda asignada. */

session_start();
require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

$error_actualizar = '';
$success_actualizar = '';
$usuario_seleccionado = null;

function obtenerViviendas($conn) {
    try {
        $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener las viviendas: " . $e->getMessage());
    }
}

function obtenerUsuarios($conn) {
    try {
        $sql = "SELECT id_usuario, nombre_usuario FROM usuario";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener los usuarios: " . $e->getMessage());
    }
}

function obtenerUsuarioSeleccionado($conn, $id_usuario) {
    try {
        $sql = "SELECT * FROM usuario WHERE id_usuario = :id_usuario";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_usuario', $id_usuario);
        $stmt->execute();
        return $stmt->fetch();
    } catch (Exception $e) {
        throw new Exception("Error al seleccionar el usuario: " . $e->getMessage());
    }
}

function actualizarUsuario($conn, $data) {
    try {
        $sql = "UPDATE usuario SET 
                    nombre_usuario = :nombre_usuario, 
                    id_vivienda = :id_vivienda, 
                    fecha_nacimiento = :fecha_nacimiento, 
                    telefono = :telefono, 
                    email = :email 
                WHERE id_usuario = :id_usuario";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
        return $stmt->rowCount() > 0;
    } catch (Exception $e) {
        throw new Exception("Error al actualizar el usuario: " . $e->getMessage());
    }
}

try {
    $viviendas = obtenerViviendas($conn);
    $usuarios = obtenerUsuarios($conn);
} catch (Exception $e) {
    $error_actualizar = $e->getMessage();
}

if (isset($_GET['id_usuario'])) {
    try {
        $usuario_seleccionado = obtenerUsuarioSeleccionado($conn, intval($_GET['id_usuario']));
    } catch (Exception $e) {
        $error_actualizar = $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_usuario'])) {
    $data = [
        ':id_usuario' => intval($_POST['id_usuario']),
        ':nombre_usuario' => trim($_POST['nombre_usuario']),
        ':id_vivienda' => intval($_POST['id_vivienda']),
        ':fecha_nacimiento' => $_POST['fecha_nacimiento'],
        ':telefono' => trim($_POST['telefono']),
        ':email' => trim($_POST['email']),
    ];

    if (empty($data[':nombre_usuario']) || empty($data[':id_vivienda']) || empty($data[':fecha_nacimiento']) || empty($data[':email'])) {
        $error_actualizar = "Por favor, complete todos los campos obligatorios.";
    } else {
        try {
            if (actualizarUsuario($conn, $data)) {
                $success_actualizar = "Usuario actualizado correctamente.";

                $usuario_seleccionado = obtenerUsuarioSeleccionado($conn, $data[':id_usuario']);
            } else {
                $error_actualizar = "No se realizaron cambios. Verifique los datos.";
            }
        } catch (Exception $e) {
            $error_actualizar = $e->getMessage();
        }
    }
}

$conn = null;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Usuarios</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/update_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Actualizar Usuario</h3>
            <?php if ($error_actualizar): ?>
                <div class="alert-error alert-danger"><h4><i class="bi bi-x-circle"></i><?php echo htmlspecialchars($error_actualizar); ?></h4></div>
            <?php endif; ?>
            <?php if ($success_actualizar): ?>
                <div class="alert-correcto"><h4><i class="bi bi-check2-circle"></i><?php echo htmlspecialchars($success_actualizar); ?></h4></div>
            <?php endif; ?>
            <form method="GET" action="">
                <div class="form-selecc">
                    <label for="id_usuario">Seleccionar Usuario:</label>
                    <select name="id_usuario" id="id_usuario" required>
                        <option value="">Seleccione un usuario</option>
                        <?php foreach ($usuarios as $usuario): ?>
                            <option value="<?php echo $usuario['id_usuario']; ?>" 
                                <?php echo (isset($_GET['id_usuario']) && $_GET['id_usuario'] == $usuario['id_usuario']) ? 'selected' : ''; ?> >
                                <?php echo htmlspecialchars($usuario['nombre_usuario']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Filtrar</button>
                </div>
            </form>

            <?php if ($usuario_seleccionado): ?>
                <form method="POST" action="" class="form-grid">
                    <input type="hidden" name="id_usuario" value="<?php echo $usuario_seleccionado['id_usuario']; ?>">
                    <div class="form-group">
                        <label for="nombre_usuario">Nombre del Usuario:</label>
                        <input type="text" id="nombre_usuario" name="nombre_usuario" value="<?php echo htmlspecialchars($usuario_seleccionado['nombre_usuario']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="id_vivienda">Seleccionar Vivienda:</label>
                        <select name="id_vivienda" id="id_vivienda" required>
                            <?php foreach ($viviendas as $vivienda): ?>
                                <option value="<?php echo $vivienda['id_vivienda']; ?>" 
                                    <?php echo ($usuario_seleccionado['id_vivienda'] == $vivienda['id_vivienda']) ? 'selected' : ''; ?> >
                                    <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo $usuario_seleccionado['fecha_nacimiento']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($usuario_seleccionado['telefono']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($usuario_seleccionado['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="boton-actualizar">Actualizar Usuario</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
