<?php
/* Este script permite al director gestionar la información de las viviendas registradas. 
Se filtra por vivienda y es posible modificar todos los datos. */

session_start();

require '../bd.php';
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

$error_actualizar = '';
$success_actualizar = '';
$vivienda_data = [];

function obtenerViviendas($conn) {
    try {
        $stmt = $conn->query("SELECT id_vivienda, nombre_vivienda FROM vivienda");
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener las viviendas: " . $e->getMessage());
    }
}

function obtenerVivienda($conn, $vivienda_id) {
    try {
        $stmt = $conn->prepare("SELECT * FROM vivienda WHERE id_vivienda = :id_vivienda");
        $stmt->execute([':id_vivienda' => $vivienda_id]);
        return $stmt->fetch();
    } catch (Exception $e) {
        throw new Exception("Error al obtener la vivienda: " . $e->getMessage());
    }
}

function actualizarVivienda($conn, $data) {
    try {
        $stmt = $conn->prepare("UPDATE vivienda 
                                SET nombre_vivienda = :nombre_vivienda,
                                    calle = :calle,
                                    numero = :numero,
                                    piso = :piso,
                                    ciudad = :ciudad,
                                    provincia = :provincia,
                                    codigo_postal = :codigo_postal,
                                    num_usuarios = :num_usuarios,
                                    informacion = :informacion
                                WHERE id_vivienda = :id_vivienda");

        $stmt->execute([
            ':nombre_vivienda' => $data['nombre_vivienda'],
            ':calle' => $data['calle'],
            ':numero' => $data['numero'],
            ':piso' => $data['piso'],
            ':ciudad' => $data['ciudad'],
            ':provincia' => $data['provincia'],
            ':codigo_postal' => $data['codigo_postal'],
            ':num_usuarios' => $data['num_usuarios'],
            ':informacion' => $data['informacion'],
            ':id_vivienda' => $data['vivienda_id'],
        ]);

        return true;
    } catch (Exception $e) {
        throw new Exception("Error al actualizar la vivienda: " . $e->getMessage());
    }
}

$viviendas = obtenerViviendas($conn);

if (isset($_GET['vivienda_id']) && !empty($_GET['vivienda_id'])) {
    $vivienda_id = $_GET['vivienda_id'];
    $vivienda_data = obtenerVivienda($conn, $vivienda_id);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $vivienda_data = [
        'vivienda_id' => $_POST['vivienda_id'],
        'nombre_vivienda' => $_POST['nombre_vivienda'],
        'calle' => $_POST['calle'],
        'numero' => $_POST['numero'],
        'piso' => $_POST['piso'],
        'ciudad' => $_POST['ciudad'],
        'provincia' => $_POST['provincia'],
        'codigo_postal' => $_POST['codigo_postal'],
        'num_usuarios' => $_POST['num_usuarios'],
        'informacion' => $_POST['informacion'],
    ];

    if (empty($vivienda_data['nombre_vivienda']) || empty($vivienda_data['calle']) || empty($vivienda_data['numero']) || empty($vivienda_data['ciudad']) || empty($vivienda_data['provincia']) || empty($vivienda_data['codigo_postal'])) {
        $error_actualizar = "Por favor, complete todos los campos obligatorios.";
    } else {
        try {
            if (actualizarVivienda($conn, $vivienda_data)) {
                $success_actualizar = "Vivienda actualizada correctamente.";
                $vivienda_data = obtenerVivienda($conn, $vivienda_data['vivienda_id']);
            } else {
                $error_actualizar = "No se realizaron cambios. Verifique los datos.";
            }
        } catch (Exception $e) {
            $error_actualizar = $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar Vivienda</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/update_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Actualizar Vivienda</h3>

            <?php if ($error_actualizar): ?>
                <div class="alert-error alert-danger">
                    <h4><i class="bi bi-x-circle"></i><?php echo htmlspecialchars($error_actualizar); ?></h4>
                </div>
            <?php endif; ?>

            <?php if ($success_actualizar): ?>
                <div class="alert-correcto">
                    <h4><i class="bi bi-check2-circle"></i><?php echo htmlspecialchars($success_actualizar); ?></h4>
                </div>
            <?php endif; ?>

            <form action="update_viviendas_d.php" method="get">
                <div class="form-selecc">
                    <label for="vivienda_id">Seleccionar Vivienda:</label>
                    <select id="vivienda_id" name="vivienda_id" class="selectvivienda">
                        <option value="">Seleccionar vivienda</option>
                        <?php foreach ($viviendas as $vivienda): ?>
                            <option value="<?= $vivienda['id_vivienda'] ?>"
                                    <?= isset($_GET['vivienda_id']) && $_GET['vivienda_id'] == $vivienda['id_vivienda'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($vivienda['nombre_vivienda']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Filtrar</button>
                </div>
            </form>

            <?php if (!empty($vivienda_data)): ?>
                <form action="update_viviendas_d.php" method="post" class="form-grid">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="vivienda_id" value="<?= htmlspecialchars($vivienda_data['id_vivienda']) ?>">

                    <div class="form-group">
                        <label for="nombre_vivienda">Nombre de la Vivienda:</label>
                        <input type="text" id="nombre_vivienda" name="nombre_vivienda"
                               value="<?= htmlspecialchars($vivienda_data['nombre_vivienda']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="calle">Calle:</label>
                        <input type="text" id="calle" name="calle"
                               value="<?= htmlspecialchars($vivienda_data['calle']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="numero">Número:</label>
                        <input type="number" id="numero" name="numero"
                               value="<?= htmlspecialchars($vivienda_data['numero']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="piso">Piso:</label>
                        <input type="text" id="piso" name="piso"
                               value="<?= htmlspecialchars($vivienda_data['piso']) ?>">
                    </div>
                    <div class="form-group">
                        <label for="ciudad">Ciudad:</label>
                        <input type="text" id="ciudad" name="ciudad"
                               value="<?= htmlspecialchars($vivienda_data['ciudad']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="provincia">Provincia:</label>
                        <input type="text" id="provincia" name="provincia"
                               value="<?= htmlspecialchars($vivienda_data['provincia']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="codigo_postal">Código Postal:</label>
                        <input type="number" id="codigo_postal" name="codigo_postal"
                               value="<?= htmlspecialchars($vivienda_data['codigo_postal']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="num_usuarios">Número de Usuarios:</label>
                        <input type="number" id="num_usuarios" name="num_usuarios"
                               value="<?= htmlspecialchars($vivienda_data['num_usuarios']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="informacion">Información Adicional:</label>
                        <textarea id="informacion" name="informacion" required><?= htmlspecialchars($vivienda_data['informacion']) ?></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="boton-actualizar">Actualizar Vivienda</button>
                    </div>
                </form>
            <?php endif; ?>

        </div>
    </main>
</div>
</body>
</html>
