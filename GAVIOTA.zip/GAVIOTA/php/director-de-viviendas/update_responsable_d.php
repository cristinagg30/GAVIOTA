<?php
/* Este script permite al director gestionar la información de los responsables asociados
a las viviendas. Se filtra por responsables para editar sus datos personales y la vivienda asignada.*/
session_start();

require '../bd.php';  
require_once 'general_director.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'director') {
    header('Location: login.php');
    exit;
}

$conn = conectar_bd();

$error_actualizar = '';
$success_actualizar = '';
$responsable_seleccionado = null;

function obtenerViviendas($conn) {
    try {
        $sql = "SELECT id_vivienda, nombre_vivienda FROM vivienda";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener las viviendas: " . $e->getMessage());
    }
}

function obtenerResponsables($conn) {
    try {
        $sql = "SELECT id_responsable, nombre_responsable FROM responsable";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    } catch (Exception $e) {
        throw new Exception("Error al obtener los responsables: " . $e->getMessage());
    }
}

function obtenerResponsableSeleccionado($conn, $id_responsable) {
    try {
        $sql = "SELECT * FROM responsable WHERE id_responsable = :id_responsable";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_responsable', $id_responsable);
        $stmt->execute();
        return $stmt->fetch();
    } catch (Exception $e) {
        throw new Exception("Error al seleccionar el responsable: " . $e->getMessage());
    }
}

function actualizarResponsable($conn, $data) {
    try {
        $sql = "UPDATE responsable SET 
                    nombre_responsable = :nombre_responsable, 
                    id_vivienda = :id_vivienda, 
                    fecha_nacimiento = :fecha_nacimiento, 
                    titulo_academico = :titulo_academico, 
                    telefono = :telefono, 
                    email = :email 
                WHERE id_responsable = :id_responsable";
        $stmt = $conn->prepare($sql);
        $stmt->execute($data);
        return $stmt->rowCount() > 0;
    } catch (Exception $e) {
        throw new Exception("Error al actualizar el responsable: " . $e->getMessage());
    }
}

try {
    $viviendas = obtenerViviendas($conn);
    $responsables = obtenerResponsables($conn);
} catch (Exception $e) {
    $error_actualizar = $e->getMessage();
}

if (isset($_GET['id_responsable'])) {
    try {
        $responsable_seleccionado = obtenerResponsableSeleccionado($conn, intval($_GET['id_responsable']));
    } catch (Exception $e) {
        $error_actualizar = $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_responsable'])) {
    $data = [
        ':id_responsable' => intval($_POST['id_responsable']),
        ':nombre_responsable' => trim($_POST['nombre_responsable']),
        ':id_vivienda' => intval($_POST['id_vivienda']),
        ':fecha_nacimiento' => $_POST['fecha_nacimiento'],
        ':titulo_academico' => trim($_POST['titulo_academico']),
        ':telefono' => trim($_POST['telefono']),
        ':email' => trim($_POST['email']),
    ];

    try {
        if (actualizarResponsable($conn, $data)) {
            $success_actualizar = "Responsable actualizado correctamente.";
            $responsable_seleccionado = obtenerResponsableSeleccionado($conn, $data[':id_responsable']);
        } else {
            $error_actualizar = "No se realizaron cambios. Verifique los datos.";
        }
    } catch (Exception $e) {
        $error_actualizar = $e->getMessage();
    }
}

$conn = null;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Responsables</title>
    <link rel="stylesheet" href="../../css/director-de-vivienda/update_d.css">
</head>
<?php include 'nav_director.php'; ?>
<body>
<div class="container-fluid">
    <main>
        <div class="form-section">
            <h3 class="title-h3">Actualizar Responsable</h3>
            <?php if ($error_actualizar): ?>
                <div class="alert-error alert-danger"><h4><i class="bi bi-x-circle"></i><?php echo htmlspecialchars($error_actualizar); ?></h4></div>
            <?php endif; ?>
            <?php if ($success_actualizar): ?>
                <div class="alert-correcto"><h4><i class="bi bi-check2-circle"></i><?php echo htmlspecialchars($success_actualizar); ?></h4></div>
            <?php endif; ?>
            <form method="GET" action="">
                <div class="form-selecc">
                    <label for="id_responsable">Seleccionar Responsable:</label>
                    <select name="id_responsable" id="id_responsable" required>
                        <option value="">Seleccione un responsable</option>
                        <?php foreach ($responsables as $responsable): ?>
                            <option value="<?php echo $responsable['id_responsable']; ?>" 
                                <?php echo (isset($_GET['id_responsable']) && $_GET['id_responsable'] == $responsable['id_responsable']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($responsable['nombre_responsable']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="boton">Filtrar</button>
                </div>
            </form>

            <?php if ($responsable_seleccionado): ?>
                <form method="POST" action="" class="form-grid">
                    <input type="hidden" name="id_responsable" value="<?php echo $responsable_seleccionado['id_responsable']; ?>">
                    <div class="form-group">
                        <label for="nombre_responsable">Nombre del Responsable:</label>
                        <input type="text" id="nombre_responsable" name="nombre_responsable" value="<?php echo htmlspecialchars($responsable_seleccionado['nombre_responsable']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="id_vivienda">Seleccionar Vivienda:</label>
                        <select name="id_vivienda" id="id_vivienda" required>
                            <?php foreach ($viviendas as $vivienda): ?>
                                <option value="<?php echo $vivienda['id_vivienda']; ?>" 
                                    <?php echo ($responsable_seleccionado['id_vivienda'] == $vivienda['id_vivienda']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($vivienda['nombre_vivienda']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo $responsable_seleccionado['fecha_nacimiento']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="titulo_academico">Título Académico:</label>
                        <input type="text" id="titulo_academico" name="titulo_academico" value="<?php echo htmlspecialchars($responsable_seleccionado['titulo_academico']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="telefono">Teléfono:</label>
                        <input type="tel" id="telefono" name="telefono" value="<?php echo htmlspecialchars($responsable_seleccionado['telefono']); ?>">
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($responsable_seleccionado['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="boton-actualizar">Actualizar Responsable</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>
</div>
</body>
</html>
