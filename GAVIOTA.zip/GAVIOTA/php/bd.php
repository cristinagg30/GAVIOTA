<?php
/* La funcion conectar_bd(), establece la conexión a la base de datos. Si la conexión falla,
captura el error y muesta el mensaje de error deteniendo la ejecucción */

    function conectar_bd() {
        $cadena_conexion = "mysql:host=127.0.0.1;dbname=viviendas_tuteladas;charset=utf8mb4";
        $usuario = "root";
        $clave = "";

        try {
            $conexion = new PDO($cadena_conexion, $usuario, $clave);
            $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conexion;
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

?>